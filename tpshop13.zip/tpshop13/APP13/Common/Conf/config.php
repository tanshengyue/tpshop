<?php
// 这里的配置信息是整个网站公用的
return array(
	//'配置项'=>'配置值'

  // 数据库配置
  'DB_TYPE'               =>  'mysql',     // 数据库类型
  'DB_HOST'               =>  '127.0.0.1', // 服务器地址
  'DB_NAME'               =>  'tpshop13',          // 数据库名
  'DB_USER'               =>  'root',      // 用户名
  'DB_PWD'                =>  'root',          // 密码
  'DB_PORT'               =>  '3306',        // 端口
  'DB_PREFIX'             =>  'tp_',    // 数据库表前缀

  // 把I函数原来的默认过滤函数调整为 htmlpurifiter
  'DEFAULT_FILTER' => 'filterXSS',
  // 邮件发送配置
  'QQ_MAIL' => array(
      'SMTP_HOST' => "smtp.qq.com",
      'SMTP_PORT' => 465,
      'MAIL_USER' => "649641514@qq.com",
      'MAIL_PWD'  => "xhgvioyhdpfmbedi",
      'MAIL_FROM_ADDR' => "649641514@qq.com",
      'MAIL_FROM_NAME' => "京西商城",
      'MAIL_SMTPSecure'=> "ssl", // 如果是25端口，则不需要加密，那么请留空！
    ),

  // 短信发送配置
  'SMS_KEY'    => 'LTAIVQuOJe2aotE5',   // 应用ID AccessKeyId
  'SMS_Secret' => 'bEFFuAi7gqGwECW2KtL2r4KuhamvZS', // 应用密钥 AccessKeySecret
);