<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
  <title><?php echo ((isset($title) && ($title !== ""))?($title):"京西商城"); ?></title>
  <link rel="stylesheet" href="/Public/Home/style/base.css" type="text/css">
  <link rel="stylesheet" href="/Public/Home/style/global.css" type="text/css">
  <link rel="stylesheet" href="/Public/Home/style/header.css" type="text/css">
  <link rel="stylesheet" href="/Public/Home/style/login.css" type="text/css">
  <link rel="stylesheet" href="/Public/Home/style/footer.css" type="text/css">
  <script src="/Public/Home/js/jquery-1.8.3.min.js"></script>
</head>
<body>
  <!-- 顶部导航 start -->
  <div class="topnav">
    <div class="topnav_bd w990 bc">
      <div class="topnav_left">
        
      </div>
      <div class="topnav_right fr">
        <ul>
          <li>您好，欢迎来到京西！[<a href="<?php echo U('User/login');?>">登录</a>] [<a href="<?php echo U('User/register');?>">免费注册</a>] </li>
          <li class="line">|</li>
          <li>我的订单</li>
          <li class="line">|</li>
          <li>客户服务</li>

        </ul>
      </div>
    </div>
  </div>
  <!-- 顶部导航 end -->
  
  <div style="clear:both;"></div>

  <!-- 页面头部 start -->
  <div class="header w990 bc mt15">
    <div class="logo w990">
      <h2 class="fl"><a href="<?php echo U('Index/index');?>"><img src="/Public/Home/images/logo.png" alt="京西商城"></a></h2>
      <?php if( CONTROLLER_NAME =='Cart' ){ ?>
        <div class="flow fr">
          <ul>
            <li class="cur">1.我的购物车</li>
            <li>2.填写核对订单信息</li>
            <li>3.成功提交订单</li>
          </ul>
        </div>
      <?php } ?>
    </div>
  </div>
  <!-- 页面头部 end -->


<style>
  /* 原来的输入太长了，我们的短信验证码的框不需要那么长 */
  .login_form .txt2{
    width: 150px;
  }
  .sms_btn{
    color: #fff;
    background-color: #ff4444;
    display: inline-block;
    cursor: pointer;
    height: 32px;
    line-height: 32px;
    font-size: 14px;
    width: 140px;
    text-align: center;
  }
  .disabled{
    cursor: no-drop;
    background-color: #ffaaaa;
  }
</style>

	<!-- 登录主体部分start -->
	<div class="login w990 bc mt10 regist">
		<div class="login_hd">
			<h2>用户注册</h2>
			<b></b>
		</div>
		<div class="login_bd">
			<div class="login_form fl">
				<form action="<?php echo U('User/register');?>" method="post">
					<ul>
						<li>
							<label>用户名：</label>
							<input type="text" class="txt" name="username" />
							<p>3-20位字符，可由中文、字母、数字和下划线组成</p>
						</li>
            <li>
              <label>昵称：</label>
              <input type="text" class="txt" name="nickname" />
              <p>可由中文、字母、数字和下划线组成</p>
            </li>            
						<li>
							<label>手机号：</label>
							<input type="text" class="txt" name="phone" />
							<p>请填写正确的手机号码</p>
						</li>
						<li>
							<label>邮箱地址：</label>
							<input type="text" class="txt" name="email" />
							<p>请填写正确的邮箱地址，用于找回密码！</p>
						</li>						
						<li>
							<label>密码：</label>
							<input type="password" class="txt" name="password" />
							<p>6-20位字符，可使用字母、数字和符号的组合，不建议使用纯数字、纯字母、纯符号</p>
						</li>
						<li>
							<label>确认密码：</label>
							<input type="password" class="txt" name="password2" />
							<p> <span>请再次输入密码</p>
						</li>
						<li>
							<label>验证码：</label>
							<input type="text" class="txt txt2" name="sms_code" />
							<span class="sms_btn">点击发送短信验证码</span>
							<p> <span>发送短信验证码</p>
						</li>						
						<li>
							<label>&nbsp;</label>
							<input type="checkbox" name="is_read" value="1" class="chb" checked="checked" /> 我已阅读并同意《用户注册协议》
						</li>
						<li>
							<label>&nbsp;</label>
							<input type="submit" value="" class="login_btn" />
						</li>
					</ul>
				</form>
			</div>
			
			<div class="mobile fl">
				<h3>手机快速注册</h3>			
				<p>中国大陆手机用户，编辑短信 “<strong>XX</strong>”发送到：</p>
				<p><strong>1069099988</strong></p>
			</div>

		</div>
	</div>
  <!-- 底部版权 end -->
	<script>
		var t;          // 定时器的返回值
		var timer = false; // 表示是否进入计时状态，true表示正在倒计时， false表示没进入倒计时了。		
	  // 发送短信验证码
		$('.sms_btn').click(function(){
			 if( timer == true ){
         return false;
       }

			 // 接收手机号码
			 var mb = $('input[name=phone]').val();
       if( mb.length < 11 ){
          $('input[name=phone]').focus();
          return false;
       }

       timer = true;  // 进入倒计时了
       var _this = $(this); // 把当前被点击的按钮对象保存在变量中
			 var time = 60; // 倒计时的时间
			 $('.sms_btn').addClass('disabled');   // 给按钮移除添加样式
       $('.sms_btn').html(time+'秒');  // 倒计时的读秒
			 clearInterval( t );
			 t = setInterval(function(){
			 	 if( time <= 1 ){
			 	 	 $('.sms_btn').removeClass('disabled'); // 给按钮 .sms_btn 移除禁用样式
			 	 	 _this.html( '点击发送短信验证码' );    // 把内容重新调整回来
			 	 	 timer = false;  //倒计时结束了，退出计时状态
			 	 	 clearInterval( t ); // 清除定时器
			 	 }else{
			 	 	 _this.html( --time + '秒' );   // 倒计时的读秒
			 	 }
			 },1000);

			 // 使用ajax发送手机号到后台，通知后台发送短信
       data = {
        'phone': mb,
       };
       $.post('<?php echo U("User/sms");?>',data, function(msg){
          // 提示用户发送短信 是否成功！
          alert( msg.message );
       },'json');
		});
	</script>


  <!-- 登录主体部分end -->
  <div style="clear:both;"></div>
  <!-- 底部版权 start -->
  <div class="footer w1210 bc mt15">
    <p class="links">
      <a href="">关于我们</a> |
      <a href="">联系我们</a> |
      <a href="">人才招聘</a> |
      <a href="">商家入驻</a> |
      <a href="">千寻网</a> |
      <a href="">奢侈品网</a> |
      <a href="">广告服务</a> |
      <a href="">移动终端</a> |
      <a href="">友情链接</a> |
      <a href="">销售联盟</a> |
      <a href="">京西论坛</a>
    </p>
    <p class="copyright">
       © 2005-2013 京东网上商城 版权所有，并保留所有权利。  ICP备案证书号:京ICP证070359号 
    </p>
    <p class="auth">
      <a href=""><img src="/Public/Home/images/xin.png" alt="" /></a>
      <a href=""><img src="/Public/Home/images/kexin.jpg" alt="" /></a>
      <a href=""><img src="/Public/Home/images/police.jpg" alt="" /></a>
      <a href=""><img src="/Public/Home/images/beian.gif" alt="" /></a>
    </p>
  </div>
 </body>
</html>