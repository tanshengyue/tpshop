<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>商品列表</title>
    <link href="/Public/Admin/css/style.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="/Public/Admin/js/jquery.js"></script>
</head>

<body>
    <div class="place">
        <span>位置：</span>
        <ul class="placeul">
            <li><a href="<?php echo U('Index/index');?>" target="_top">首页</a></li>
            <li><a href="<?php echo U('Goods/index');?>">商品管理</a></li>
            <li>列表</li>
        </ul>
    </div>
    <div class="rightinfo">
        <div class="tools">
            <ul class="toolbar">
                <li><a href="<?php echo U('Goods/add');?>"><span><img src="/Public/Admin/images/t01.png" /></span>添加</a></li>
                <li id="del_confirm"><span><img src="/Public/Admin/images/t03.png" /></span>删除</li>
            </ul>
        </div>
        <table class="tablelist">
            <thead>
              <tr>
                <th><input name="delall" type="checkbox" value="" id="checkAll" /></th>
                <th>编号</th>
                <th>标题</th>
                <th>logo</th>
                <th>分类</th>
                <th>品牌</th>
                <th>库存数量</th>
                <th>销量</th>
                <th>售价</th>
                <th>市场价</th>
                <th>上架时间</th>
                <th>添加时间</th>
                <th>排序</th>
                <th>操作</th>
              </tr>
            </thead>
            <tbody>
              <?php if(is_array($goodsList)): foreach($goodsList as $key=>$goods): ?><tr>
                <td><input name="del" type="checkbox" value="<?php echo ($goods['goods_id']); ?>" /></td>
                <td><?php echo ($goods['goods_id']); ?></td>
                <td><?php echo ($goods['goods_name']); ?></td>
                <td>
                  <?php if($goods['goods_logo_thumb'] != ''): ?><img style="max-width: 50px;max-height: 50px;" src="/Uploads/<?php echo ($goods['goods_logo_thumb']); ?>"><?php endif; ?>
                </td>
                <td><?php echo ($goods['cate_id']); ?></td>
                <td><?php echo ($goods['brand_id']); ?></td>
                <td><?php echo ($goods['goods_number']); ?></td>
                <td><?php echo ($goods['sale_number']); ?></td>
                <td><?php echo ($goods['goods_price']); ?></td>
                <td><?php echo ($goods['market_price']); ?></td>
                <td><?php echo ($goods['sale_time']==0?'未上架':date('Y-m-d H:i:s',$goods['sale_time'])); ?></td>
                <td><?php echo (date('Y-m-d H:i:s',$goods['created_at'])); ?></td>
                <td><?php echo ($goods['sort']); ?></td>
                <td>
                  <a href="#" class="tablelink">查看</a>
                  <a href="<?php echo U('Goods/pics',array('id'=>$goods['goods_id']));?>" class="tablelink">相册</a>
                  <a href="<?php echo U('Goods/edit',array('id'=>$goods['goods_id']));?>" class="tablelink">编辑</a>
                  <a href="<?php echo U('Goods/del',array('id'=>$goods['goods_id']));?>" class="tablelink">删除</a>
                </td>
              </tr><?php endforeach; endif; ?>
            </tbody>
        </table>
        <div class="pagin">
          <div class="message">共<i class="blue"><?php echo ($total); ?></i>条记录，当前显示第&nbsp;<i class="blue"><?php echo I('get.p',1,'intval');?>&nbsp;</i>页</div>
          <style>
          /*page*/
          .pagin{position:relative;margin-top:10px;padding:0 12px;}
          .pagin .blue{color:#056dae;font-style:normal;}
          .pagin .paginList{position:absolute;right:12px;top:0;}
          .pagin .paginList a,.pagin .paginList span{float:left;width:31px;height:28px;border:1px solid #DDD; text-align:center;line-height:30px;border-left:none;color:#3399d5;}
          .pagin .paginList a:first-child,.pagin .paginList span:first-child{border-left:1px solid #DDD;}
          .pagin .paginList a:first-child,.pagin .paginList span:first-child{border-bottom-left-radius:5px;border-top-left-radius:5px;}
          .pagin .paginList a:last-child,.pagin .paginList span:last-child{border-bottom-right-radius:5px;border-top-right-radius:5px;}
          .pagin .paginList .current{background:#f5f5f5; cursor:default;color:#737373;}
          .pagin .paginList a:hover,.pagin .paginList span:hover{background:#f5f5f5;}
          </style>
          <div class="paginList"><?php echo ($pagehtml); ?></div>
        </div>
        <div class="tip">
            <div class="tiptop"><span>提示信息</span>
                <a></a>
            </div>
            <div class="tipinfo">
                <span><img src="/Public/Admin/images/ticon.png" /></span>
                <div class="tipright">
                    <p>是否确认对信息的修改 ？</p>
                    <cite>如果是请点击确定按钮 ，否则请点取消。</cite>
                </div>
            </div>
            <div class="tipbtn">
                <input name="" type="button" class="sure" value="确定" />&nbsp;
                <input name="" type="button" class="cancel" value="取消" />
            </div>
        </div>
    </div>
</body>
<script>
  $('.tablelist tbody tr:odd').addClass('odd');

  // 删除功能中多选框的全选和反选
  $('#checkAll').on('change', function(){
    $('input[name=del]').attr('checked', $(this).is(':checked') );
  });

  // 批量删除的确认框
  $('#del_confirm').on('click', function(){

    // 判断用户是否有选择了要删除的数据
    // :checkd 获取所有选中的多选框元素
    var length = $('input[name=del]:checked').length; // 获取当前页面中被选中状态的多选框的数量
    if( length < 1 ){
      alert("您当前没有选中要删除的数据！");
      return false; // 阻止代码继续执行
    }

    if( !confirm("您确定要删除这些数据吗？") ){
      return false;
    }

    // 获取所有删除数据的商品id
    var goods_list = [];
    $('input[name=del]:checked').each(function(key,item){
      goods_list.push( item.value );
    });
    // 把数组成员通过逗号拼接成字符串
    goods_list = goods_list.join(',');
      
    // 发送ajax
    data = {
      'id': goods_list,
    };
    $.post('<?php echo U("Goods/delall");?>', data, function(msg){
      // 根据控制器返回结果，进行页面的操作
      if( msg.status ){
        alert(msg.message);
        location.reload(); // 当前页面删除
      }
    },'json');
  });
</script>

</html>