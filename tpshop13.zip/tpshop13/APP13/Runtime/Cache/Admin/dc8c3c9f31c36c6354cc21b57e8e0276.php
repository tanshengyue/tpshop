<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>订单详情</title>
    <link href="/Public/Admin/css/style.css" rel="stylesheet">
    <script src="/Public/Admin/js/jquery.js"></script>
</head>
<body>
    <div class="place">
        <span>位置：</span>
        <ul class="placeul">
            <li><a href="<?php echo U('Index/index');?>" target="_top">首页</a></li>
            <li><a href="<?php echo U('Order/index');?>">订单管理</a></li>
            <li>详情</li>
        </ul>
    </div>
    <div class="formbody">
        <div class="formtitle">
          <span>基本信息</span>
        </div>
        <form action="<?php echo U('Order/edit');?>" method="post">
            <ul class="forminfo current">
                <li>
                  <label>订单状态</label>
                  <input type="hidden" name="order_id" value="<?php echo ($Order['order_id']); ?>" />
                  <?php if($Order['order_status']== 1 ): ?><select name="order_status" class="dfinput">
                        <option value="0">未收款</option>
                        <option value="2">确认收款</option>
                    </select><?php endif; ?>
                  <?php if($Order['order_status']== 2 ): ?><select name="order_status" class="dfinput">
                        <option value="2">未发货</option>
                        <option value="3">已发货</option>
                    </select><br>
                    <input type="text" class="dfinput" placeholder="物流公司" name="shipping_com" />
                    <input type="text" class="dfinput" placeholder="快递单号" name="shipping_number" /><?php endif; ?> 
                  <?php if($Order['order_status']== 5 ): ?><select name="order_status" class="dfinput">
                        <option value="3">未收货</option>
                        <option value="6">已完成</option>
                    </select><br />
                    <div style="position: absolute;top: 100px;right: 40px;"><?php echo ($kuaidi_html); ?></div><?php endif; ?>
                  <?php if($Order['order_status']== 6 ): ?>已完成
                    <div style="position: absolute;top: 100px;right: 40px;"><?php echo ($kuaidi_html); ?></div><?php endif; ?>                                                  
                </li>
                <li>
                    <label>&nbsp;</label>
                    <input id="btnSubmit" type="submit" class="btn" value="确认保存" />
                </li>
            </ul>
        </form>
    </div>
</body>
</html>