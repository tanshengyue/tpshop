<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>添加商品</title>
    <link href="/Public/Admin/css/style.css" rel="stylesheet">
    <script src="/Public/Admin/js/jquery.js"></script>
    <!-- 时间选择器 -->
    <link href="/Public/Admin/js/timer/calendar.css" rel="stylesheet">
    <script src="/Public/Admin/js/timer/calendar.js"></script>
    <!-- 富文本编辑器 -->
    <script charset="utf-8" src="/Public/Admin/js/ueditor/ueditor.config.js"></script>
    <script charset="utf-8" src="/Public/Admin/js/ueditor/ueditor.all.min.js"></script>
    <script charset="utf-8" src="/Public/Admin/js/ueditor/lang/zh-cn/zh-cn.js"></script>
    <style>
    #preview{
      position: absolute;
      top: 100px;
      right: 50px;
      max-width: 400px;
      max-height: 400px;
      min-height: 200px;
      min-width: 200px;
    }
    .formtitle span{
      position: static; /* 取消标签的定位属性 */
      margin-right: 10px;
      cursor: pointer;
      border-color: #fff;
    }
    .formtitle span:hover,.formtitle span:first-child{ border-color: #66c9f3; }
    .forminfo{ display: none; }
    .current{ display: block; }
    .add_btn,.sub_btn{
      vertical-align: middle;
      cursor: pointer;
    }
    </style>
</head>

<body>
    <div class="place">
        <span>位置：</span>
        <ul class="placeul">
            <li><a href="<?php echo U('Index/index');?>" target="_top">首页</a></li>
            <li><a href="<?php echo U('Goods/index');?>">商品管理</a></li>
            <li>添加</li>
        </ul>
    </div>
    <div class="formbody">
        <div class="formtitle">
          <span>基本信息</span>
          <span>商品描述</span>
          <span>商品属性</span>
        </div>
        <form action="<?php echo U('Goods/add');?>" method="post" enctype="multipart/form-data">
            <ul class="forminfo current">
                <li>
                  <label>商品名称</label>
                  <input name="goods_name" placeholder="请输入商品名称" type="text" class="dfinput" /><i>名称不能超过30个字符</i>
                </li>
                <li>
                  <label>商品价格</label>
                  <input name="goods_price" placeholder="请输入商品价格" type="text" class="dfinput" /><i></i>
                </li> 
                <li>
                  <label>市场价格</label>
                  <input name="market_price" placeholder="请输入市场价格,注意要比商品价格要贵" type="text" class="dfinput" /><i></i>
                </li>                                
                <li>
                  <label>logo图片</label>
                  <input name="goods_logo_src" id="f" onchange="change()" type="file" /><i></i>
                  <img id="preview"/>
                </li>
                <li>
                  <label>商品数量</label>
                  <input name="goods_number" placeholder="请输入商品数量" type="text" class="dfinput" />
                </li>
                <li>
                  <label>虚拟销量</label>
                  <input name="sale_number" placeholder="请输入虚拟数量" type="text" class="dfinput" />
                </li>                
                <li>
                  <label>商品分类</label>
                  <select name="cate_id" class="dfinput">
                    <option value="1">游戏本</option>
                    <option value="2">商务本</option>
                    <option value="3">学生电脑</option>
                    <option value="4">美颜手机</option>
                  </select>
                </li>
                <li>
                  <label>商品品牌</label>
                  <select name="brand_id" class="dfinput">
                    <option value="1">苹果</option>
                    <option value="2">黑马</option>
                    <option value="3">荣耀</option>
                    <option value="4">雪梨</option>
                  </select>
                </li>                  
                <li>
                  <label>商品重量</label>
                  <input name="goods_weight" placeholder="请输入商品重量" type="text" class="dfinput" />
                </li>
                <li>
                    <label>上架时间</label>
                    <input name="sale_time" id="sale_time" placeholder="留空则表示不上架" type="text" class="dfinput" />
                </li>
                <li>
                  <label>商品排序</label>
                  <input name="sort" placeholder="数值越大，越靠后显示" type="text" class="dfinput" />
                </li>
            </ul>
            <ul class="forminfo">                          
                <li>
                    <label>商品描述</label>
                    <textarea style="float: left" name="goods_desc" id="goods_desc"></textarea>
                </li>
            </ul>
            <ul class="forminfo">                          
                <li>
                    <label>商品类型</label>
                    <!-- 这一块代码可以直接从GoodsAttribute/index.html模板中复制过来 -->
                    <select name="type_id" class="dfinput">
                        <option value="0">--请选择类型--</option>
                        <?php if(is_array($typeList)): foreach($typeList as $key=>$type): ?><option value="<?php echo ($type['type_id']); ?>"><?php echo ($type['type_name']); ?></option><?php endforeach; endif; ?>
                    </select>
                </li>
            </ul>
            <ul>
                <li>
                    <label>&nbsp;</label>
                    <input id="btnSubmit" type="submit" class="btn" value="确认保存" />
                </li>
            </ul>
        </form>
    </div>
</body>
<!-- 上传文件预览效果 -->
<script src="/Public/Admin/js/placeImage.js"></script>
<script>
    // 时间选择器的初始化
    Calendar.setup({
        inputField     :    "sale_time",             // input输入框的id值
        ifFormat       :    "%Y-%m-%d %H:%M:%S",  // 时间显示的格式 分别代表 年-月-日 时:分:秒
        showsTime      :    true,                 // 是否显示 时间输入框
        timeFormat     :    "24"                  // 时间的显示进制 12小时制/24小时制
    });

    // 富文本编辑器的初始化
    var ue = UE.getEditor('goods_desc',{
      initialFrameWidth:600  //初始化编辑器宽度,默认1000
      ,initialFrameHeight:220  //初始化编辑器高度,默认320
      , toolbars: [[
        'fullscreen', 'source', '|', 'undo', 'redo', '|',
        'bold', 'italic', 'underline', 'fontborder', 'strikethrough', 'superscript', 'subscript', 'removeformat', 'formatmatch', 'autotypeset','|', 'forecolor', 'backcolor', 'insertorderedlist', 'insertunorderedlist', 'selectall', 'cleardoc', '|',
        'rowspacingtop', 'rowspacingbottom', 'lineheight', '|',
        'customstyle', 'paragraph', 'fontfamily', 'fontsize', '|',
        'directionalityltr', 'directionalityrtl', 'indent', '|',
        'justifyleft', 'justifycenter', 'justifyright', 'justifyjustify', '|', 'touppercase', 'tolowercase', '|',
        'link', 'unlink', 'anchor', '|', 'imagenone', 'imageleft', 'imageright', 'imagecenter', '|',
        'simpleupload', 'insertimage', 'preview'
      ]]
    });

    // 点击选项标签切换显示表单内容
    $('.formtitle span').on('click', function(){
      // 当前被点击标签的下标
      var key = $(this).index();
      // 设置当前被点击标签的边框高亮
      $(this).css('border-color','#66c9f3').siblings().css('border-color','#fff');
      // 让同样下标的表单块(ul标签)显示出来
      // siblings 表示当前标签其他兄弟元素
      $('.forminfo').eq(key).show()
                    .siblings('.forminfo').hide(); // 其他的.forminfo标签隐藏掉
                    
    });


    // 点击切换商品类型显示对应的属性列表
    $('select[name=type_id]').on('change', function(){
      var type_id = $(this).val();
      data = {
        'id':type_id,
      };
      // 声明一个变量保存当前下拉框对象，方便在ajax函数中使用
      var _parent = $(this).parent();
      
      // 每次在切换商品类型的时候，都要把所有的属性li标签清理掉。只保留商品类型的那个li
      _parent.siblings().remove();

      $.post('<?php echo U("GoodsAttribute/ajax_list");?>', data, function(msg){
        // 判断服务器返回的数组是否有属性列表，如果空数组，则直接阻止代码继续执行
        if( msg.length < 1 ){
          return false;
        }
        var html = ""; // 声明变量存储新增的表单数据[属性输入框]
        $(msg).each(function(key,item){
          // 普通的js字符串是不支持换行的，但是在新的js中，有一个反引号``表示可以可以换行的多行字符串
          // 我们使用js的多行字符串来输出内容，多行字符串里面也可以使用变量
          // ${变量名}
          // js的长字符串是不支持低版本浏览器[IE8以下]
          html += `<li><label>`;
          if( item['attr_sel'] == 1 ){
            html += `<img class="add_btn" src="/Public/Admin/images/t01.png">`;
          }
          html += `${item['attr_name']}</label>`;
          // 设置一个隐藏域，用于保存当前属性值对应的属性ID
          html += `<input type="hidden" name="attr_id[]" value="${item['attr_id']}" />`;
          // 根据属性的录入方式显示对应的输入框[0表示单行文本框，1表示下拉列表]
          if( item['attr_write'] == 0 ){
            html += `<input name="attr_value[]" type="text" class="dfinput" />`;
          }else{
            html += `<select name="attr_value[]" class="dfinput">`;
            // 把attr_vals的参数值进行分割成数组，并循环显示到下拉列表的option选项中
            var attr_vals = item['attr_vals'].split(',');
            $(attr_vals).each(function(key,value){
              if( value != "" ){
                html += `<option value="${value}">${value}</option>`;
              }
            });
            html += `</select>`;
          }

          // 如果属性是单选属性，则需要提交一个框给用户输入当前属性商品对应的价格
          if( item['attr_sel'] == 1 ){ // 单选属性
            html +=`&nbsp;属性价格 <input style="width:100px;" type="text" name="attr_price[]" class="dfinput"/>`;
          }else{
            html +=`<input type="hidden" value="0" name="attr_price[]"/>`;
          }
          html += `</li>`;
        });
        _parent.after(html); // 把新的表单数据追加下拉列表的父级标签li后面
      
      },'json');
    });

    // 点击"+"号图片实现动态增加属性框的功能
    $('.forminfo').on('click','.add_btn',function(){
      // 获取当前被点击图片的父级元素label标签的父级元素li，因为一个属性就时一行
      var _parent = $(this).parent().parent();
      // 把当前属性所在的li标签复制一份，进行追加
      var li = _parent.clone();
      li.find('input[type=attr_value\\[\\]]').val(""); // 复制的时候要清空掉原来的input框的值[只删除text文本框的值]
      li.find('img').attr('src','/Public/Admin/images/t03.png').removeClass('add_btn').addClass('sub_btn');
      _parent.after( li );
    });

    // 点击"-"号图片实现动态减少属性框的功能
    $('.forminfo').on('click','.sub_btn', function(){
      var _parent = $(this).parent().parent();
      _parent.remove();
    });
</script>
</html>