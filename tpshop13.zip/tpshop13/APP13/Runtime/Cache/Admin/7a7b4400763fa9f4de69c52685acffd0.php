<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>编辑商品</title>
    <link href="/Public/Admin/css/style.css" rel="stylesheet">
    <script src="/Public/Admin/js/jquery.js"></script>
    <!-- 时间选择器 -->
    <link href="/Public/Admin/js/timer/calendar.css" rel="stylesheet">
    <script src="/Public/Admin/js/timer/calendar.js"></script>
    <!-- 富文本编辑器 -->
    <script charset="utf-8" src="/Public/Admin/js/ueditor/ueditor.config.js"></script>
    <script charset="utf-8" src="/Public/Admin/js/ueditor/ueditor.all.min.js"></script>
    <script charset="utf-8" src="/Public/Admin/js/ueditor/lang/zh-cn/zh-cn.js"></script>
    <style>
    .formtitle span{
      position: static; /* 取消标签的定位属性 */
      margin-right: 10px;
      cursor: pointer;
      border-color: #fff;
    }
    .formtitle span:hover,.formtitle span:first-child{ border-color: #66c9f3; }
    .forminfo{ display: none; }
    .current{ display: block; }
    #preview{
      position: absolute;
      top: 100px;
      right: 50px;
      max-width: 400px;
      max-height: 400px;
      min-height: 200px;
      min-width: 200px;
    }
    </style>
</head>

<body>
    <div class="place">
        <span>位置：</span>
        <ul class="placeul">
            <li><a href="<?php echo U('Index/index');?>" target="_top">首页</a></li>
            <li><a href="<?php echo U('Goods/index');?>">商品管理</a></li>
            <li>编辑</li>
        </ul>
    </div>
    <div class="formbody">
        <div class="formtitle">
          <span>基本信息</span>
          <span>商品描述</span>
          <span>商品属性</span>                  
        </div>
        <form action="<?php echo U('Goods/edit');?>" method="post" enctype="multipart/form-data">
            <input type="hidden" name="goods_id" value="<?php echo ($goodsInfo['goods_id']); ?>" />
            <input type="hidden" name="old_logo_src" value="<?php echo ($goodsInfo['goods_logo_src']); ?>" />
            <input type="hidden" name="old_logo_thumb" value="<?php echo ($goodsInfo['goods_logo_thumb']); ?>" />
            <ul class="forminfo current">
                <li>
                  <label>商品名称</label>
                  <input name="goods_name" value="<?php echo ($goodsInfo['goods_name']); ?>" placeholder="请输入商品名称" type="text" class="dfinput" /><i>名称不能超过30个字符</i>
                </li>
                <li>
                  <label>商品价格</label>
                  <input name="goods_price" value="<?php echo ($goodsInfo['goods_price']); ?>" placeholder="请输入商品价格" type="text" class="dfinput" /><i></i>
                </li> 
                <li>
                  <label>市场价格</label>
                  <input name="market_price" value="<?php echo ($goodsInfo['market_price']); ?>" placeholder="请输入市场价格,注意要比商品价格要贵" type="text" class="dfinput" /><i></i>
                </li>                                
                <li>
                  <label>logo图片</label>
                  <input name="goods_logo_src" id="f" onchange="change()" type="file" /><i></i>
                  <img id="preview" src="/Uploads/<?php echo ($goodsInfo['goods_logo_src']); ?>" />
                </li>
                <li>
                  <label>商品数量</label>
                  <input name="goods_number" value="<?php echo ($goodsInfo['goods_number']); ?>" placeholder="请输入商品数量" type="text" class="dfinput" />
                </li>
                <li>
                  <label>虚拟销量</label>
                  <input name="sale_number" value="<?php echo ($goodsInfo['sale_number']); ?>" placeholder="请输入虚拟数量" type="text" class="dfinput" />
                </li>                
                <li>
                  <label>商品分类</label>
                  <select name="cate_id" class="dfinput">
                    <option value="1">游戏本</option>
                    <option value="2">商务本</option>
                    <option value="3">学生电脑</option>
                    <option value="4">美颜手机</option>
                  </select>
                </li>
                <li>
                  <label>商品品牌</label>
                  <select name="brand_id" class="dfinput">
                    <option value="1">苹果</option>
                    <option value="2">黑马</option>
                    <option value="3">荣耀</option>
                    <option value="4">雪梨</option>
                  </select>
                </li>                  
                <li>
                  <label>商品重量</label>
                  <input name="goods_weight" value="<?php echo ($goodsInfo['goods_weight']); ?>" placeholder="请输入商品重量" type="text" class="dfinput" />
                </li>
                <li>
                    <label>上架时间</label>
                    <input name="sale_time" value="<?php echo (date('Y-m-d H:i:s',$goodsInfo['sale_time'])); ?>" id="sale_time" placeholder="留空则表示不上架" type="text" class="dfinput" />
                </li>
                <li>
                  <label>商品排序</label>
                  <input name="sort" value="<?php echo ($goodsInfo['sort']); ?>" placeholder="数值越大，越靠后显示" type="text" class="dfinput" />
                </li>
            </ul>
            <ul class="forminfo">                          
                <li>
                    <label>商品描述</label>
                    <textarea style="float: left" name="goods_desc" id="goods_desc"><?php echo ($goodsInfo['goods_desc']); ?></textarea>
                </li>
            </ul>
            <ul class="forminfo">                          
                <li>
                    <label>商品类型</label>
                    <!-- 这一块代码可以直接从GoodsAttribute/index.html模板中复制过来 -->
                    <select name="type_id" class="dfinput">
                        <option value="0">--请选择类型--</option>
                        <?php if(is_array($typeList)): foreach($typeList as $key=>$type): ?><option <?php echo ($type['type_id'] == $goodsInfo['type_id']?'selected':''); ?> value="<?php echo ($type['type_id']); ?>"><?php echo ($type['type_name']); ?></option><?php endforeach; endif; ?>
                    </select>
                </li>
                <?php if(is_array($goodsAttr)): foreach($goodsAttr as $key=>$attr): ?><li>
                  <label><?php echo ($attr['attr_name']); ?></label>
                  <input type="hidden" name="attr_id[]" value="<?php echo ($attr['attr_id']); ?>"/>
                  <input type="hidden" name="value_id[]" value="<?php echo ($attr['value_id']); ?>"/>
                  <?php if($attr['attr_write'] == 0): ?><input name="attr_value[]" value="<?php echo ($attr['attr_value']); ?>" type="text" class="dfinput" />
                  <?php else: ?>
                    <?php $attr_vals = explode(',',$attr['attr_vals']);?>
                    <select name="attr_value[]" class="dfinput">
                      <?php if(is_array($attr_vals)): foreach($attr_vals as $key=>$value): ?><option <?php echo ($attr['attr_value'] == $value?'selected':''); ?> value="<?php echo ($value); ?>"><?php echo ($value); ?></option><?php endforeach; endif; ?>
                    </select><?php endif; ?>
                  <?php if($attr['attr_sel'] == 1): ?>&nbsp;属性价格 <input style="width:100px;" type="text" name="attr_price[]" class="dfinput" value="<?php echo ($attr['attr_price']); ?>"/>
                  <?php else: ?>
                    <input type="hidden" value="0" name="attr_price[]"/><?php endif; ?>
                </li><?php endforeach; endif; ?>
            </ul>            
            <ul>
                <li>
                    <label>&nbsp;</label>
                    <input id="btnSubmit" type="submit" class="btn" value="确认保存" />
                </li>
            </ul>
        </form>
    </div>
</body>
<!-- 上传文件预览效果 -->
<script src="/Public/Admin/js/placeImage.js"></script>
<script>
    // 时间选择器的初始化
    Calendar.setup({
        inputField     :    "sale_time",             // input输入框的id值
        ifFormat       :    "%Y-%m-%d %H:%M:%S",  // 时间显示的格式 分别代表 年-月-日 时:分:秒
        showsTime      :    true,                 // 是否显示 时间输入框
        timeFormat     :    "24"                  // 时间的显示进制 12小时制/24小时制
    });

    // 富文本编辑器的初始化
    var ue = UE.getEditor('goods_desc',{
      initialFrameWidth:600  //初始化编辑器宽度,默认1000
      ,initialFrameHeight:220  //初始化编辑器高度,默认320
      , toolbars: [[
        'fullscreen', 'source', '|', 'undo', 'redo', '|',
        'bold', 'italic', 'underline', 'fontborder', 'strikethrough', 'superscript', 'subscript', 'removeformat', 'formatmatch', 'autotypeset','|', 'forecolor', 'backcolor', 'insertorderedlist', 'insertunorderedlist', 'selectall', 'cleardoc', '|',
        'rowspacingtop', 'rowspacingbottom', 'lineheight', '|',
        'customstyle', 'paragraph', 'fontfamily', 'fontsize', '|',
        'directionalityltr', 'directionalityrtl', 'indent', '|',
        'justifyleft', 'justifycenter', 'justifyright', 'justifyjustify', '|', 'touppercase', 'tolowercase', '|',
        'link', 'unlink', 'anchor', '|', 'imagenone', 'imageleft', 'imageright', 'imagecenter', '|',
        'simpleupload', 'insertimage', 'preview'
      ]]
    });

    // 点击选项标签切换显示表单内容
    $('.formtitle span').on('click', function(){
      // 当前被点击标签的下标
      var key = $(this).index();
      // 设置当前被点击标签的边框高亮
      $(this).css('border-color','#66c9f3').siblings().css('border-color','#fff');
      // 让同样下标的表单块(ul标签)显示出来
      // siblings 表示当前标签其他兄弟元素
      $('.forminfo').eq(key).show()
                    .siblings('.forminfo').hide(); // 其他的.forminfo标签隐藏掉
                    
    });

</script>
</html>