<?php
// Home模块配置
return array(
	//'配置项'=>'配置值'
  // 模板常量
  'TMPL_PARSE_STRING' => array(
    '__JS__'  => '/Public/Home/js',
    '__CSS__' => '/Public/Home/style',
    '__IMG__' => '/Public/Home/images',
  ),

  // 开启模版布局
  'LAYOUT_ON'   => true,
  // 保存公共部分代码的模板文件名，这个文件默认叫layout.html，默认保存在View视图根目录下
  'LAYOUT_NAME'  => 'layout', 
);