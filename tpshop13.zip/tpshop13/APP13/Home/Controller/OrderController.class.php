<?php
  namespace Home\Controller;
  use Home\Controller\CommonController as Controller;
  // 订单控制器
  class OrderController extends Controller
  {
    // 初始化方法
    public function _initialize(){
      $this->cart = new \Common\Library\Cart;
    }

    // 订单结算页面
    public function add(){
      // 获取购物车中的信息
      $Goods = M('GoodsInfo');
      $cartInfo = $this->cart->getCartInfo();
      // 在循环中把商品的图片获取到
      foreach( $cartInfo as $key => $item ){
        $goodsInfo = $Goods->find( $item['goods_id'] );
        // 把商品的logo缩略图添加到cartInfo这个购物车信息数组中
        $cartInfo[$key]['goods_logo_thumb'] = $goodsInfo['goods_logo_thumb'];
      }
      $this->cartInfo = $cartInfo;

      // 获取购物车中的商品总价格
      $this->numberPrice = $this->cart->getNumberPrice();

      $this->display();
    }

    // 生成订单
    public function save(){
      if( !IS_POST ){
        $this->error('当前页面不存在！');
      }

      $order = D('Order');
      if( !$order->create() || !$order_id = $order->add() ){
        $this->error('生成订单失败！' . $order->getError() );
      }

      // 保存订单成功以后，清空购物车
      $this->cart->delall();

      // 如果生成订单成功了，则跳转到支付页面[附带订单ID]
      $this->success('生成订单成功！', U('Order/alipay', array('id'=> $order_id ) ) );die;

    }

    // 发送支付的页面
    public function alipay(){
      $alipay = D('Alipay');
      // 获取订单的ID
      $order_id = I('get.id');
      $orderInfo = D('Order')->find( $order_id );
      $out_trade_no = $orderInfo['order_number']; // 订单号 
      $subject      = "京西购物"; // 订单标题
      $total_amount = $orderInfo['order_price']; // 订单价格
      $alipay->pay($out_trade_no, $subject, $total_amount);
    }

    // 接收支付结果的js跳转回来的地址中的get参数
    public function return_url(){
      $res = D('Alipay')->return_url();
      if( $res ){
        $this->success('正在跳转到会员中心！', U('User/index') );die;
      }
    }

    // 接收支付宝服务器的ajax访问，ajax post异步通知
    // 注意：
    // 异步通知，因为我们当前在本地开发，所以我们可以先把代码写上，以后在线上服务器中进行测试
    public function notify_url(){
      
      D('Alipay')->notify_url();
    }

  }