<?php
  namespace Home\Controller;
  use Home\Controller\CommonController as Controller;
  // 购物车控制器
  class CartController extends Controller
  {
    // 初始化方法
    public function _initialize(){
      $this->cart = new \Common\Library\Cart;
    }

    // 购物车列表页
    public function index(){
      // 获取购物车中的信息
      $Goods = M('GoodsInfo');
      $cartInfo = $this->cart->getCartInfo();
      // 在循环中把商品的图片获取到
      foreach( $cartInfo as $key => $item ){
        $goodsInfo = $Goods->find( $item['goods_id'] );
        // 把商品的logo缩略图添加到cartInfo这个购物车信息数组中
        $cartInfo[$key]['goods_logo_thumb'] = $goodsInfo['goods_logo_thumb'];
      }
      $this->cartInfo = $cartInfo;

      // 获取购物车中的商品总价格
      $this->numberPrice = $this->cart->getNumberPrice();

      $this->display();
    }

    // 给购物车添加商品
    public function add(){
      if( !IS_AJAX ){
        $this->error('页面不存在！');
      }
      // 接受商品信息
      $goods['goods_id']          = I('post.goods_id');
      $goods['goods_name']        = I('post.goods_name');
      $goods['goods_price']       = I('post.goods_price');
      $goods['goods_buy_number']  = I('post.buy_number');
      $goods['goods_total_price'] = $goods['goods_buy_number'] * $goods['goods_price'];
      $goods['goods_attr']        = I('post.goods_attr');
      // 调用购物车工具类的add方法把商品信息添加到$_SESSION中
      $this->cart->add( $goods );
      // 返回最新的商品总数量和总价格
      return $this->ajaxReturn( $this->cart->getNumberPrice() );
    }

    // 给购物车更新商品信息
    public function edit(){
      $goods_id = I('post.goods_id');
      $number   = I('post.number');
      // 更新指定的商品ID对应的数量
      $this->cart->changeNumber( $number, $goods_id );
      return $this->ajaxReturn( array('status'=>true) );
    }

    //给购物车删除商品
    public function del(){
      if( !IS_AJAX ){
        $this->error('页面不存在！');
      }
      // 商品ID
      $goods_id = I('post.id');
      // 从购物车session中移除对应的商品id的商品信息
      $this->cart->del( $goods_id );
      return $this->ajaxReturn( $this->cart->getNumberPrice() );
    }
  }