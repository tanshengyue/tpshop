<?php
  namespace Home\Controller;
  use Home\Controller\CommonController as Controller;
  // 会员控制器
  class UserController extends Controller
  {
    // 初始化
    public function _initialize(){
      $this->User = D('User');
    }
    // 会员中心
    public function index(){

      $this->display();
    }

    // 会员注册
    public function register(){
      // 判断是否有post数据提交
      if( IS_POST ){

        // 验证短信验证码是否正确
        $code = I('post.sms_code');
        if( $code != session('sms_code') ){
          $this->error('验证码有误！');
        }

        // 判断验证码是否在有效时间范围内[例如10分钟内有效]
        if( time() - 600 > session('sms_time') ){
          $this->error('验证码超时，已失效！');die;
        }

        if( !$this->User->create() || !$user_id = $this->User->add() ){
          $this->error('注册失败！' . $this->User->getError() );
        }

        // 如果注册成功，则清除保存在session中的短信验证码
        session('sms_code', null);
        session('sms_time', null);

        // 保存登录状态
        session('user_login',1);
        session('nickname', I('post.nickname') );
        session('user_id', $user_id);
        // 更新登录时间
        $data['user_id']    = $user_id;
        $data['login_time'] = time();
        $data['login_ip']   = $_SERVER['REMOTE_ADDR'];
        $this->User->save($data);

        $this->success('注册成功！', U('User/index') );die;

      }
      $this->display();
    }

    // 会员登录
    public function login(){
      // 判断是否有post数据提交
      if( IS_POST ){
        // 根据用户提交的帐号获取用户信息
        $where['username'] = I('post.username');
        $userInfo = D('User')->where( $where )->find();
        if( !$userInfo ){
          $this->error('帐号或密码错误！');
        }

        // 判断密码是否正确
        $password = I('post.password'); // 登录页面提交过来的用户密码
        $salt     = $userInfo['salt'];    // 保存在数据表中的盐值
        $pwd      = $userInfo['password'];// 保存在数据表中的密码加密串 
        // 使用自定义的辅助函数password把用户密码和盐值进行加密，判断生成的加密串是否和数据表中$pwd一致。
        if( password($password, $salt) == $pwd ){
          // 保存登录状态
          session('user_login',1);
          session('user_id',$userInfo['user_id']);
          session('nickname', $userInfo['nickname']);
          // 更新当前管理员的登录状态
          D('User')->login_time = time();
          D('User')->login_ip = $_SERVER['REMOTE_ADDR']; // 客户端的登录IP地址
          D('User')->save();
          $this->success('登录成功！', U('Index/index') );die;
        }else{
          $this->error('帐号或密码错误！');
        }
      }
      $this->display();
    }

    // 退出登录
    public function logout(){
      session('user_login',null);
      session('user_id',null);

      $this->success('退出登录成功！', U('Index/index') );die;

    }


    // 发送短信
    public function sms(){
      if( !IS_AJAX ){
        $this->error('当前页面不存在！');
      }
      $phone = I('post.phone');
      $number = mt_rand(10000,99999); // 生成一个随机数字
      session('sms_code', $number);
      session('sms_time', time() );
      $data  = array(
        'number' => $number,
      );
      // 调用上面内置进来的短信发送功能
      $res = \Common\Library\Sms::sendSms($phone, $data );

      if( $res->Code == 'OK' ){
        $data = array(
          'status'  => 1,
          'message' => '发送短信成功！',
        );
      }else{
        $data = array(
          'status'  => 0,
          'message' => '发送短信失败！请重新尝试或联系管理员', 
        );
      }
      return $this->ajaxReturn( $data );
    }

    // 第三方登录-qq登录的回调地址
    public function qq(){
      // 我们要在这个方法中获取qq回调给我们网站的用户信息，代码参考example/oauth/callback.php文件
      require_once("./Plugin/qq/qqConnectAPI.php");
      $qc = new \QC(); // 实例化对象时，要加上反斜杠
      // 这个是接下来获取qq用户信息的临时asscss token值，有效期是2小时
      $token = $qc->qq_callback(); 
      // 这个就是qq用户在我们网站中的openid，就是唯一标识符 
      $openid = $qc->get_openid();
      // 根据openid是否保存在数据表中，区分老用户和新用户
      $where['openid'] = $openid;
      $userInfo = D('User')->where($where)->find();
      if( !$userInfo ){
        // 依靠用户登录过来的数据，如果是第一次登录，则获取qq里面的用户信息
        $qc = new \QC($token, $openid);
        $data = $qc->get_user_info();
        $info = array(
          'openid'    => $openid,
          'nickname'  => $data['nickname'],
          'sex'       => $data['gender'] == '男'?1:2,
          'created_at'=> time(),
        );

        $res = D('User')->add( $info );      // 新添加用户信息
        $userInfo = D('User')->find($res);   // 把用户的信息再次查询出来
      }
      // 保存登录状态
      session('user_login', 1 );
      session('user_id',  $userInfo['user_id'] );
      session('nickname', $userInfo['nickname'] );

      // 更新登录时间
      $data = [];
      $data['user_id']    = $userInfo['user_id'];
      $data['login_ip']   = $_SERVER['REMOTE_ADDR'];
      $data['login_time'] = time();
      D('User')->save($data);
      $url = U('Index/index');
      echo <<<DDD
      <script>
        opener.location.href="$url"; // opener 弹出子窗的父级窗口
        window.close();              // 当前子窗口关闭
      </script>
DDD;
    }

    // 弹出QQ登录的窗口[这里的代码负责在点击图标以后，弹出一个窗口]
    public function qq_login(){
      // 基于index.php入口文件写上对应的地址
      require_once("./Plugin/qq/qqConnectAPI.php");
      $qc = new \QC();
      $qc->qq_login();
    }
  }