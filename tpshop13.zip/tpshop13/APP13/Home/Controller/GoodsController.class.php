<?php
namespace Home\Controller;
use Home\Controller\CommonController as Controller;
// 前台商品控制器
class GoodsController extends Controller {
    // 商品列表
    public function index(){

      // 查询所有的商品信息
      $where['is_deleted'] = 0;                    // 被软删除的商品不能显示
      $where['sale_time']  = array('LT', time() ); // 上架小于当前时间的商品才能显示出来
      $where['sale_time']  = array('NEQ', 0);      // 还要过滤掉那些上架时间为0的未上架商品
      // 判断是否有分类参数
      if( $cid = I('get.cid',0,'intval') ){
        $where['cate_id'] = $cid;
      }
      // 判断是否有品牌参数
      if( $bid = I('get.bid',0,'intval') ){
        $where['brand_id'] = $bid;
      }

      $this->goodsList = M('GoodsInfo')->where($where)->select();

      $this->title = "商品列表";
      $this->display();
    }

    // 商品详情
    public function detail(){
      // 接受商品ID
      $goods_id = I('get.id',0,'intval');
      $where['is_deleted'] = 0;                    // 被软删除的商品不能显示
      $where['sale_time']  = array('LT', time() ); // 上架小于当前时间的商品才能显示出来
      $where['sale_time']  = array('NEQ', 0);      // 还要过滤掉那些上架时间为0的未上架商品      
      // 普通商品信息
      $this->goodsInfo = M('GoodsInfo')->where( $where )->find( $goods_id );
      if( !$this->goodsInfo ){
        $this->error('页面不存在！');
      }

      // 商品相册
      $w['goods_id'] = $goods_id;
      $this->picsList = M('GoodsPics')->where( $w )->select();
      
      // 唯一属性
      $w['attr_sel'] = 0;
      $this->attrList = M('GoodsAttributeValue')->alias('gav')->join('__GOODS_ATTRIBUTE__ as ga ON ga.attr_id = gav.attr_id')->where( $w )->select();
      
      // 单选属性
      $w['attr_sel'] = 1;
      $radioAttrList = M('GoodsAttributeValue')->alias('gav')->join('__GOODS_ATTRIBUTE__ as ga ON ga.attr_id = gav.attr_id')->where( $w )->select(); 
      // 因为单选属性时一个属性名称对应多个属性值的情况，所以我们需要以 属性id 进行分组
      $radio = [];
      foreach( $radioAttrList as $item ){
        $radio[$item['attr_name']][] = $item;
      }
      $this->radioAttrList = $radio;

      $this->display();
    }
}