<?php
  namespace Home\Controller;
  use Think\Controller;
  // 前台公共控制器
  class CommonController extends Controller
  {
    public function __construct(){
      parent::__construct();

      $this->get_category();

      // 登录防翻墙
      $this->check_login(); 
    }

    // 登录防翻墙
    public function check_login(){
      // 设置需要进行登录防翻墙的页面
      $excep = array(
        'User/index', // 会员中心
        'Order/add',  // 订单结算页面
      );

      // 获取当前页面的控制器名和方法名
      $current = CONTROLLER_NAME . '/' . ACTION_NAME;

      // 判断当前页面是否需要进行登录防翻墙操作
      if( !in_array($current, $excep ) ){
        return ;
      }
      if( !session('?user_login') ){
        $this->error('对不起！您尚未登录，请登录！', U('User/login') );
      }
    }

    // 获取所有的商品分类信息
    public function get_category(){
      // 获取全部商品分类
      $where['is_show'] = 1;
      $this->cateList = D('GoodsCategory')->where($where)->order('sort ASC')->select();
    }


  }