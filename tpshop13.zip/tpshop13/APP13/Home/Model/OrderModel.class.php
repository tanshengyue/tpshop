<?php
  namespace Home\Model;
  use Think\Model;
  // 前台的订单模型
  class OrderModel extends Model{
    // 表名
    protected $tableName = "order_info";
    // 字段定义
    protected $pk = 'order_id';// 主键
    protected $fields = array('order_id', 'user_id', 'order_number', 'order_price', 'order_pay', 'invoice_head', 'invoice_company', 'invoice_content', 'consignee_name', 'consignee_address', 'consignee_mobile', 'order_status', 'shipping_com', 'shipping_number', 'created_at');

    // 添加订单之前，先把商品相关和会员的id等信息补充完整
    public function _before_insert(&$data,$options){
      // 获取当前登录的用户id
      $data['user_id']      = session('user_id');
      // 生成一个唯一的订单号
      $data['order_number'] = date('YmdHis') . mt_rand( 1000000, 9999999 );
      // 订单创建[也可以在自动完成中实现]
      $data['created_at']   = time();
      // 订单的价格，也就是购物车商品中的总价格
      $cart = new \Common\Library\Cart;
      $cartinfo = $cart->getNumberPrice();
      $data['order_price']  = $cartinfo['price'];
    }

    // 订单生成以后，把订单对应的商品信息也进行保存
    // $data 中保存了添加订单成功以后的订单ID
    public function _after_insert( $data, $options ){
      $cart = new \Common\Library\Cart;
      $goodsList = $cart->getCartInfo();
      $orderGoods = [];
      $i = 0; // 设置这个$i的目的是为了清空数组的$key值，因为$goodsList的子数组下标是商品ID
      foreach($goodsList as $item ){
        $orderGoods[$i]               = $item;         
        $orderGoods[$i]['goods_attr'] = json_encode( $item['goods_attr'] , 256);// 256表示不要把中文进行编码 
        $orderGoods[$i]['order_id']   = $data['order_id']; // 订单ID
        $i++;
      }
      // 批量添加丁订单的商品信息
      $res = D('OrderGoods')->addAll( $orderGoods );
      // 如果批量添加不成功，则删除本次生成的订单
      if( !$res ){
        $this->delete( $data['order_id'] );
      }

    }
  }