<?php
  namespace Home\Model;
  use Think\Model;
  // 前台的商品分类模型
  class GoodsCategoryModel extends Model{
    // 表名
    protected $tableName = "goods_category";
    // 字段定义
    protected $pk = 'cate_id';// 主键
    protected $fields = array('cate_id', 'cate_pid', 'cate_name', 'description', 'keywords', 'is_show', 'show_nav', 'sort');
  }