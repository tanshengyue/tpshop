<?php
  namespace Home\Model;
  use Think\Model;
  // 会员信息模型
  class UserModel extends Model{
    // 表名
    protected $tableName = "user_info";
    // 字段定义
    protected $pk = 'user_id';// 主键
    protected $fields = array('user_id', 'username', 'password', 'salt', 'nickname', 'email', 'phone', 'openid', 'sex', 'check', 'check_code', 'login_time', 'login_ip', 'created_at', 'deleted_at');

    // 自动验证
    protected $_validate = array(
      array('username', 'require', '登录帐号必须填写', 1, '', 3),
      array('username', '', '登录帐号已存在！', 1, 'unique', 3),
      array('password', 'require', '密码必须填写', 1, '', 3),
      // 验证用户的密码和确认密码是否一致
      array('password','password2','密码和确认密码必须一致',2,'confirm',3),
      array('email','email','邮箱地址格式不正确！',1,'',3),
      array('phone','/\d{11}/','手机号码格式不正确！',1,'regex',3),
    );

    // 自动完成
    protected $_auto = array(
      array('created_at', 'time', 1, 'function'),
    );

    // 添加功能的前置钩子
    public function _before_insert(&$data, $options){
      $data['salt']     = create_string(6);
      $data['password'] = password($data['password'], $data['salt']);
    }
  }