<?php
  namespace Home\Model;
  // 支付宝的模型类，因为不涉及到数据表的操作，所以我们可以选择不集成Model类
  class AlipayModel {
    // 接受的订单的信息，发送支付请求到支付宝中
    // 商户订单号，订单名称，付款金额，商品描述，
    public function pay($out_trade_no, $subject, $total_amount, $body ){
      // 基于框架的入口文件index.php来写地址
      // 1. 引入核心的类库文件
      require_once './Plugin/alipay/config.php';
      require_once './Plugin/alipay/pagepay/service/AlipayTradeService.php';
      require_once './Plugin/alipay/pagepay/buildermodel/AlipayTradePagePayContentBuilder.php';
      // 2. 构造请求支付宝服务器的表单
      $payRequestBuilder = new \AlipayTradePagePayContentBuilder();
      $payRequestBuilder->setBody($body);
      $payRequestBuilder->setSubject($subject);
      $payRequestBuilder->setTotalAmount($total_amount);
      $payRequestBuilder->setOutTradeNo($out_trade_no);

      $aop = new \AlipayTradeService($config);
      // 3. 返回表单
      return $aop->pagePay($payRequestBuilder,$config['return_url'],$config['notify_url']);
    }

    // post 异步通知
    public function notify_url(){
      // 引入核心文件
      require_once './Plugin/alipay/config.php';
      require_once './Plugin/alipay/pagepay/service/AlipayTradeService.php';

      $arr=$_POST;
      $alipaySevice = new \AlipayTradeService($config); 
      $alipaySevice->writeLog(var_export($_POST,true));
      $result = $alipaySevice->check($arr); // 验证接收到的数据是否是正确的!
      if( $result ) {// 验证成功，并不代表支付成功！
        $out_trade_no = $_POST['out_trade_no'];    // 订单号
        $trade_no     = $_POST['trade_no'];        // 支付宝交易号
        $trade_status = $_POST['trade_status'];    // 交易状态

        // 支付成功！
        if ($_POST['trade_status'] == 'TRADE_FINISHED' || $_POST['trade_status'] == 'TRADE_SUCCESS') {
          // 获取订单信息
          $where['order_number'] = $out_trade_no;
          $orderInfo = D('Order')->where($where)->find();
          // 原来的订单状态
          if( $orderInfo['order_status'] == 0 ){
            // 修改订单状态
            $data['order_status'] = 1; // 支付成功的状态，通过状态判断
            D('Order')->where($where)->save($data);
            // 减少商品的数量[根据订单ID查询出当前订单的商品信息，然后到商品信息表减少对应的商品的数量]
          }
        }
        echo "success"; //请不要修改或删除，【千万不要删除】
      }else {
        //验证失败
        echo "fail";   //请不要修改或删除，【千万不要删除】
      }
    }

    // get 同步跳转
    public function return_url(){
      // 引入核心文件
      require_once './Plugin/alipay/config.php';
      require_once './Plugin/alipay/pagepay/service/AlipayTradeService.php';

      $arr=$_GET;
      $alipaySevice = new \AlipayTradeService($config); 
      $result = $alipaySevice->check($arr);

      if($result) { // 验证成功，表示数据安全了而已，不代表支付成功！
        //订单号
        $out_trade_no = htmlspecialchars($_GET['out_trade_no']);
        //支付宝交易号
        $trade_no = htmlspecialchars($_GET['trade_no']);
        // 获取订单信息
        $where['order_number'] = $out_trade_no;
        $orderInfo = D('Order')->where($where)->find();
        // 原来的订单状态
        if( $orderInfo['order_status'] == 0 ){
          // 修改订单状态
          $data['order_status'] = 1; // 支付成功的状态，通过状态判断
          $res = D('Order')->where($where)->save($data);
          // 减少商品的数量[根据订单ID查询出当前订单的商品信息，然后到商品信息表减少对应的商品的数量]
          if( $res ){
            return true;
          }
        }
      } else {
          //验证失败
          echo "验证失败";
      }
    }
  }