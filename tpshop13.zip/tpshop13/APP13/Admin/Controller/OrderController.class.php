<?php
  namespace Admin\Controller;
  use Admin\Controller\CommonController as Controller;
  // 订单控制器
  class OrderController extends Controller{
    public function _initialize(){
      $this->Order = D('Order');
    }

    // 订单列表页
    public function index(){
      // 总数量
      $this->total = $this->Order->count();
      // 实例化分页类
      $page = new \Think\Page( $this->total, 10 );
      // 分配配置
      $page->rollPage = 3; // 每一页显示的数字页码数量
      $page->lastSuffix = false; // 关闭尾页的数字显示功能
      $page->setConfig('first','首页');
      $page->setConfig('last','尾页');
      $page->setConfig('prev','上页');
      $page->setConfig('next','下页');
      // 生成页码
      $this->pagehtml = $page->show();

      $where = [];
      // 接受搜索条件[收货人]
      $consignee_name = I('get.consignee_name');
      if( $consignee_name ){
        $where['consignee_name'] = array('LIKE',"%$consignee_name%");
      }

      // 接受搜索条件[指定之间内的订单]
      $sar = strtotime( I('get.sar') );
      $end = strtotime( I('get.end') );
      if( $sar > 0 && $end > 0 && $end > $sar ){
        // 查询开始时间戳
        $where['created_at'] = array('GT', $sar);
        // 查询结束时间戳
        $where['created_at'] = array('LT', $end);
      }

      // 查询所有的未删除订单信息
      $this->orderList = $this->Order->limit($page->firstRow,$page->listRows)
                                     ->where($where)
                                     ->select();
      $this->display();
    }

    // 添加
    // public function add(){
    //   // 判断是否有post数据提交
    //   if( IS_POST ){
    //     // 使用create接受和校验数据一旦有错误
    //     // 或者 添加订单信息时有错误
    //     if( !$this->Order->create() || !$this->Order->add() ){
    //       $this->error('添加订单失败！' . $this->Order->getError() );
    //     }
    //     $this->success('添加订单成功！', U('Order/index') );die;
    //   }
    //   $this->display();
    // }

    // 编辑
    public function edit(){
      // 判断是否有post数据提交
      if( IS_POST ){
        // 使用create方法接受数据并校验
        // save 保存数据
        if( !$this->Order->create() || !$this->Order->save() ){
          $this->error('编辑订单失败！' . $this->Order->getError() );
        }

        $this->success('编辑订单成功！', U('Order/index') );die;

      }

      // 接受订单ID，并根据ID查询对应的数据
      $order_id = I('get.id',0,'intval');
      $where['order_id'] = $order_id;
      // 订单信息
      $this->Order = $this->Order->find($order_id);
      if( !$this->Order ){
        $this->error('非法参数，访问失败！');
      }

      // 显示快递信息[实际上，显示快递的信息应该用前台会员的订单详情中显示而不是后台]
      $key = "e46ad5cbf651c868"; // 应用密钥
      $com = "jd"; // 快递公司[可以为空！]
      $nu  = "70929598229"; // 快递单号
      // 请求快递接口
      $url = "http://www.kuaidi100.com/applyurl?key=$key&com=$com&nu=$nu";
      $kuaidi = file_get_contents( $url);
      // 快递的代码
      $this->kuaidi_html = <<<DDD
      <iframe src="$kuaidi" style="width: 600px; height: 340px;" frameborder="0"></iframe>
DDD;
      $this->display();
    }

    // 删除订单[硬删除]
    public function del(){
      $order_id = I('get.id',0,'intval');
      $typeInfo = $this->Order->find($order_id);
      if( !$typeInfo ){
        $this->error('非法参数，访问失败！');
      }

      // 因为上面已经查询了数据啦，所以这里不写编辑条件，模型也知道我们要编辑的是哪一条数据了
      $res = $this->Order->delete(); 
      if( $res ){
        $this->success('删除订单成功！', U('Order/index') );die;
      }
      $this->error('删除订单失败！' . $this->Order->getError() );
    }

    // 批量删除
    public function delall(){
      $order_list = I('post.id');

      // 因为上面已经查询了数据啦，所以这里不写编辑条件，模型也知道我们要编辑的是哪一条数据了
      $where['order_id'] = array('IN', $order_list ); // 等同于 "where order_id IN ($order_list)";
      $res = $this->Order->where($where)->delete();
      if( $res ){
        $data = array('status'=>true,'message'=>'删除成功！');
      }else{
        $data = array('status'=>false,'message'=>'删除失败！');
      }
      
      return $this->ajaxReturn($data);
    
    }

  }