<?php
  namespace Admin\Controller;
  use Admin\Controller\CommonController as Controller;
  // 角色控制器
  class RoleController extends Controller{
    public function _initialize(){
      $this->Role = D('Role');
    }

    // 角色列表页
    public function index(){
      // 总数量
      $this->total = $this->Role->count();
      // 实例化分页类
      $page = new \Think\Page( $this->total, 10 );
      // 分配配置
      $page->rollPage = 3; // 每一页显示的数字页码数量
      $page->lastSuffix = false; // 关闭尾页的数字显示功能
      $page->setConfig('first','首页');
      $page->setConfig('last','尾页');
      $page->setConfig('prev','上页');
      $page->setConfig('next','下页');
      // 生成页码
      $this->pagehtml = $page->show();

      // 查询所有的未删除角色信息
      $this->roleList = $this->Role->limit($page->firstRow,$page->listRows)
                                        ->select();
      $this->display();
    }

    // 添加
    public function add(){
      // 判断是否有post数据提交
      if( IS_POST ){
        // 使用create接受和校验数据一旦有错误
        // 或者 添加角色信息时有错误
        if( !$this->Role->create() || !$this->Role->add() ){
          $this->error('添加角色失败！' . $this->Role->getError() );
        }
        $this->success('添加角色成功！', U('Role/index') );die;
      }
      $this->display();
    }

    // 编辑
    public function edit(){
      // 判断是否有post数据提交
      if( IS_POST ){
        // 使用create方法接受数据并校验
        // save 保存数据
        if( !$this->Role->create() || !$this->Role->save() ){
          $this->error('编辑角色失败！' . $this->Role->getError() );
        }

        $this->success('编辑角色成功！', U('Role/index') );die;

      }

      // 接受角色ID，并根据ID查询对应的数据
      $role_id = I('get.id',0,'intval');
      $where['role_id'] = $role_id;
      // 角色信息
      $this->Role = $this->Role->find($role_id);
      if( !$this->Role ){
        $this->error('非法参数，访问失败！');
      }

      $this->display();
    }

    // 删除角色[硬删除]
    public function del(){
      $role_id = I('get.id',0,'intval');
      $roleInfo = $this->Role->find($role_id);
      if( !$roleInfo ){
        $this->error('非法参数，访问失败！');
      }

      // 因为上面已经查询了数据啦，所以这里不写编辑条件，模型也知道我们要编辑的是哪一条数据了
      $res = $this->Role->delete(); 
      if( $res ){
        $this->success('删除角色成功！', U('Role/index') );die;
      }
      $this->error('删除角色失败！' . $this->Role->getError() );
    }

    // 批量删除
    public function delall(){
      $role_list = I('post.id');

      // 因为上面已经查询了数据啦，所以这里不写编辑条件，模型也知道我们要编辑的是哪一条数据了
      $where['role_id'] = array('IN', $role_list ); // 等同于 "where role_id IN ($role_list)";
      $res = $this->Role->where($where)->delete();
      if( $res ){
        $data = array('status'=>true,'message'=>'删除成功！');
      }else{
        $data = array('status'=>false,'message'=>'删除失败！');
      }

      return $this->ajaxReturn($data);
    }

    // 分配权限
    public function auth(){
      $role = D('Role');
      $auth = D('Auth');
      if( IS_POST ){
        $data['role_id']  = I('post.role_id'); // 角色ID
        $data['auth_ids'] = implode(',',I('post.auth_id') );
        // 根据当前提供的权限ID获取权限的信息
        $where['auth_pid'] = array('NEQ',0); // 因为顶级权限是没有控制器名和方法名的，所以我们过滤掉
        $where['auth_id']  = array('IN',$data['auth_ids']);   // where `auth_id` IN (1,2,3,4,5);
        $auth_vals = $auth->where($where)->select();
        $vals = [];
        foreach($auth_vals as $item){
          $vals[] = $item['auth_controller'] . '-' . $item['auth_action'];
        }
        $data['auth_vals'] = implode(',',$vals);
        if( $role->save($data) ){ // 分配权限是对角色信息的更新操作，所以使用save
          $this->success('分配权限成功！',U('Role/index') );die;
        }else{
          $this->error('分配权限失败！');die;
        }
      }

      $role_id = I('get.id');// 角色ID
      $this->roleInfo = $role->find($role_id);
      $this->roleAuth = explode(',',$this->roleInfo['auth_ids']); // 当前角色所拥有的权限
      // dump( $this->roleAuth );
      // 查询所有的顶级权限
      $where['auth_pid'] = array('EQ',0);
      $this->topAuth = $auth->where($where)->select();
      // 查询所有的子权限
      $where['auth_pid'] = array('NEQ',0);
      $this->sonAuth = $auth->where($where)->select();

      $this->display();
    }
  }