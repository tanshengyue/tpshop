<?php
  namespace Admin\Controller;
use Admin\Controller\CommonController as Controller;
  // 权限控制器
  class AuthController extends Controller{
    public function _initialize(){
      $this->Auth = D('Auth');
    }

    // 权限列表页
    public function index(){
      // 总数量
      $this->total = $this->Auth->count();
      // 实例化分页类
      $page = new \Think\Page( $this->total, 100 );
      // 分配配置
      $page->rollPage = 3; // 每一页显示的数字页码数量
      $page->lastSuffix = false; // 关闭尾页的数字显示功能
      $page->setConfig('first','首页');
      $page->setConfig('last','尾页');
      $page->setConfig('prev','上页');
      $page->setConfig('next','下页');
      // 生成页码
      $this->pagehtml = $page->show();

      // 查询所有的未删除权限信息
      $authList = $this->Auth->limit($page->firstRow,$page->listRows)
                                        ->select();
      // 生成具有层级效果的权限信息数组
      $this->authList = getTree($authList);

      $this->display();
    }

    // 添加
    public function add(){
      // 判断是否有post数据提交
      if( IS_POST ){
        // 使用create接受和校验数据一旦有错误
        // 或者 添加权限信息时有错误
        if( !$this->Auth->create() || !$this->Auth->add() ){
          $this->error('添加权限失败！' . $this->Auth->getError() );
        }
        $this->success('添加权限成功！', U('Auth/index') );die;
      }

      // 查询所有的顶级权限[条件：where auth_pid = 0]
      $where['auth_pid'] = 0;
      $this->topAuth = $this->Auth->where($where)->select();
      $this->display();
    }

    // 编辑
    public function edit(){
      // 判断是否有post数据提交
      if( IS_POST ){
        // 使用create方法接受数据并校验
        // save 保存数据
        if( !$this->Auth->create() || !$this->Auth->save() ){
          $this->error('编辑权限失败！' . $this->Auth->getError() );
        }

        $this->success('编辑权限成功！', U('Auth/index') );die;

      }

      // 接受权限ID，并根据ID查询对应的数据
      $auth_id = I('get.id',0,'intval');
      $where['auth_id'] = $auth_id;
      // 权限信息
      $this->Auth = $this->Auth->find($auth_id);
      if( !$this->Auth ){
        $this->error('非法参数，访问失败！');
      }

      $this->display();
    }

    // 删除权限[硬删除]
    public function del(){
      $auth_id = I('get.id',0,'intval');
      $authInfo = $this->Auth->find($auth_id);
      if( !$authInfo ){
        $this->error('非法参数，访问失败！');
      }

      // 因为上面已经查询了数据啦，所以这里不写编辑条件，模型也知道我们要编辑的是哪一条数据了
      $res = $this->Auth->delete(); 
      if( $res ){
        $this->success('删除权限成功！', U('Auth/index') );die;
      }
      $this->error('删除权限失败！' . $this->Auth->getError() );
    }

    // 批量删除
    public function delall(){
      $auth_list = I('post.id');

      // 因为上面已经查询了数据啦，所以这里不写编辑条件，模型也知道我们要编辑的是哪一条数据了
      $where['auth_id'] = array('IN', $auth_list ); // 等同于 "where auth_id IN ($auth_list)";
      $res = $this->Auth->where($where)->delete();
      if( $res ){
        $data = array('status'=>true,'message'=>'删除成功！');
      }else{
        $data = array('status'=>false,'message'=>'删除失败！');
      }
      
      return $this->ajaxReturn($data);
    
    }
  }