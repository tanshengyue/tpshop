<?php
  namespace Admin\Controller;
use Admin\Controller\CommonController as Controller;
  // 管理员控制器
  class AdminController extends Controller{
    public function _initialize(){
      $this->Admin = D('Admin');
    }

    // 管理员列表页
    public function index(){

      // 总数量
      $this->total = $this->Admin->count();
      // 实例化分页类
      $page = new \Think\Page( $this->total, 10 );
      // 分配配置
      $page->rollPage = 3; // 每一页显示的数字页码数量
      $page->lastSuffix = false; // 关闭尾页的数字显示功能
      $page->setConfig('first','首页');
      $page->setConfig('last','尾页');
      $page->setConfig('prev','上页');
      $page->setConfig('next','下页');
      // 生成页码
      $this->pagehtml = $page->show();

      // 查询所有的未删除管理员信息
      $this->adminList = $this->Admin->alias('a')
                                     ->join('__ROLE__ as r ON r.`role_id`=a.`role_id`','LEFT')
                                     ->limit($page->firstRow,$page->listRows)
                                     ->select();
      $this->display();
    }

    // 添加
    public function add(){
      // 判断是否有post数据提交
      if( IS_POST ){
        // 使用create接受和校验数据一旦有错误
        // 或者 添加管理员信息时有错误
        if( !$this->Admin->create() || !$this->Admin->add() ){
          $this->error('添加管理员失败！' . $this->Admin->getError() );
        }
        $this->success('添加管理员成功！', U('Admin/index') );die;
      }
      // 查询所有的角色
      $this->roleList = D('Role')->select();

      $this->display();
    }

    // 编辑
    public function edit(){
      // 判断是否有post数据提交
      if( IS_POST ){
        // 使用create方法接受数据并校验
        // save 保存数据
        if( !$this->Admin->create() || !$this->Admin->save() ){
          $this->error('编辑管理员失败！' . $this->Admin->getError() );
        }

        $this->success('编辑管理员成功！', U('Admin/index') );die;

      }

      // 接受管理员ID，并根据ID查询对应的数据
      $admin_id = I('get.id',0,'intval');
      $where['admin_id'] = $admin_id;
      // 管理员信息
      $this->Admin = $this->Admin->find($admin_id);
      if( !$this->Admin ){
        $this->error('非法参数，访问失败！');
      }

      $this->display();
    }

    // 删除管理员[硬删除]
    public function del(){
      $admin_id = I('get.id',0,'intval');
      $adminInfo = $this->Admin->find($admin_id);
      if( !$adminInfo ){
        $this->error('非法参数，访问失败！');
      }

      // 因为上面已经查询了数据啦，所以这里不写编辑条件，模型也知道我们要编辑的是哪一条数据了
      $res = $this->Admin->delete(); 
      if( $res ){
        $this->success('删除管理员成功！', U('Admin/index') );die;
      }
      $this->error('删除管理员失败！' . $this->Admin->getError() );
    }

    // 批量删除
    public function delall(){
      $admin_list = I('post.id');

      // 因为上面已经查询了数据啦，所以这里不写编辑条件，模型也知道我们要编辑的是哪一条数据了
      $where['admin_id'] = array('IN', $admin_list ); // 等同于 "where admin_id IN ($admin_list)";
      $res = $this->Admin->where($where)->delete();
      if( $res ){
        $data = array('status'=>true,'message'=>'删除成功！');
      }else{
        $data = array('status'=>false,'message'=>'删除失败！');
      }
      
      return $this->ajaxReturn($data);

    }

  }