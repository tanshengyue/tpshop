<?php
  namespace Admin\Controller;
  use Admin\Controller\CommonController as Controller;
  // 商品控制器
  class GoodsController extends Controller{
    public function _initialize(){
      $this->GoodsInfo = D('GoodsInfo');
    }

    // 商品列表页
    public function index(){
      $where['deleted_at'] = 0;
      // 总数量
      $this->total = $this->GoodsInfo->where($where)->count();
      // 实例化分页类
      $page = new \Think\Page( $this->total, 10 );
      // 分配配置
      $page->rollPage = 3; // 每一页显示的数字页码数量
      $page->lastSuffix = false; // 关闭尾页的数字显示功能
      $page->setConfig('first','首页');
      $page->setConfig('last','尾页');
      $page->setConfig('prev','上页');
      $page->setConfig('next','下页');
      // 生成页码
      $this->pagehtml = $page->show();

      // 查询所有的未删除商品信息
      $this->goodsList = $this->GoodsInfo->field("goods_id,goods_name,goods_price,goods_number,brand_id,cate_id,goods_logo_thumb,sale_time,created_at,sale_number,sort,market_price")
                                         ->order("sort asc,goods_id desc")
                                         ->limit($page->firstRow,$page->listRows)
                                         ->where($where)
                                         ->select();
      $this->display();
    }

    // 添加
    public function add(){
      // 判断是否有post数据提交
      if( IS_POST ){
        // dump( I('post.') );die;
        // 使用create接受和校验数据一旦有错误
        // 或者 添加商品信息时有错误
        if( !$this->GoodsInfo->create() || !$this->GoodsInfo->add() ){
          $this->error('添加商品失败！' . $this->GoodsInfo->getError() );
        }
        $this->success('添加商品成功！', U('Goods/index') );die;
      }

      // 查询所有的商品类型
      $this->typeList = D('GoodsType')->select();
      $this->display();
    }

    // 编辑
    public function edit(){
      // 判断是否有post数据提交
      if( IS_POST ){
        // 使用create方法接受数据并校验
        // save 保存数据
        if( !$this->GoodsInfo->create() || !$this->GoodsInfo->save() ){
          $this->error('编辑商品失败！' . $this->GoodsInfo->getError() );
        }

        $this->success('编辑商品成功！', U('Goods/index') );die;

      }

      // 接受商品ID，并根据ID查询对应的数据
      $goods_id = I('get.id',0,'intval');
      $where['goods_id'] = $goods_id;
      // 商品信息
      $this->goodsInfo = $this->GoodsInfo->where($where)->find();
      if( !$this->goodsInfo ){
        $this->error('非法参数，访问失败！');
      }

      // 查询当前商品的属性信息
      $GAV = D('GoodsAttributeValue');
      $this->goodsAttr = $GAV->alias('gav')
                             ->where($where) // 商品的查询条件
                             ->join('__GOODS_ATTRIBUTE__ as ga ON ga.attr_id = gav.attr_id')
                             ->select();
      // dump( $this->goodsAttr );
      // 查询所有的商品类型
      $this->typeList = D('GoodsType')->select();
      $this->display();
    }

    // 删除商品[软删除]
    public function del(){
      $goods_id = I('get.id',0,'intval');
      $goodsInfo = $this->GoodsInfo->find($goods_id);
      if( !$goodsInfo ){
        $this->error('非法参数，访问失败！');
      }

      $data['deleted_at'] = time(); 
      // 因为上面已经查询了数据啦，所以这里不写编辑条件，模型也知道我们要编辑的是哪一条数据了
      $res = $this->GoodsInfo->where($where)->save($data); 
      if( $res ){
        $this->success('删除商品成功！', U('Goods/index') );die;
      }
      $this->error('删除商品失败！' . $this->GoodsInfo->getError() );
    }

    // 批量删除
    public function delall(){
      $goods_list = I('post.id');

      $data['deleted_at'] = time(); 
      // 因为上面已经查询了数据啦，所以这里不写编辑条件，模型也知道我们要编辑的是哪一条数据了
      $where['goods_id'] = array('IN', $goods_list ); // 等同于 "where goods_id IN ($goods_list)";
      $res = $this->GoodsInfo->where($where)->save($data);
      if( $res ){
        $data = array('status'=>true,'message'=>'删除成功！');
      }else{
        $data = array('status'=>false,'message'=>'删除失败！');
      }
      
      return $this->ajaxReturn($data);
    
    }

    // 商品图片相册
    public function pics(){
      // 实例化商品相册模型
      $this->GoodsPics = D('GoodsPics');
      // 判断是否有post数据提交
      if( IS_POST ){
        // $goods_id = I('post.goods_id');
        if( !$this->GoodsPics->mul_pics() ){
          $this->error('上传相册图片处理失败！' . $this->GoodsPics->getError() );
        }

        $this->success('上传相册图片处理成功！', U('Goods/pics',array('id'=> I('post.goods_id') ) ) );die;
      }

      $this->goods_id = I('get.id',0,'intval');
      $this->goodsInfo = $this->GoodsInfo->find($this->goods_id);
      // 根据商品ID查询对应的相册图片
      $where['goods_id'] = $this->goods_id;
      $this->picsList = $this->GoodsPics->where($where)->select();
      $this->display();
    }

    // 删除相册图片
    public function delpics(){
      // 判断是否是ajax请求
      if( !IS_AJAX ){
        $this->error('非法请求！');die;
      }

      $this->GoodsPics = D('GoodsPics');

      $pics_id = I('get.pics_id');
      $Picsinfo = $this->GoodsPics->find( $pics_id );
      $pics_bg = './Uploads/' . $Picsinfo['pics_bg']; // 原图[大图]
      $pics_md = './Uploads/' . $Picsinfo['pics_md']; // 中图
      $pics_sm = './Uploads/' . $Picsinfo['pics_sm']; // 小图
      if( $this->GoodsPics->delete() ){
        if( is_file( $pics_bg ) ){
          unlink( $pics_bg );
        }
        if( is_file( $pics_md ) ){
          unlink( $pics_md );
        }
        if( is_file( $pics_sm ) ){
          unlink( $pics_sm );
        }   
 
        $data = array('status'=>true,'message'=>'删除图片成功！');
      }else{
        $data = array('status'=>false,'message'=>'删除图片失败！' . $this->GoodsPics->getError() );
      }

      return $this->ajaxReturn( $data );
    }

  }