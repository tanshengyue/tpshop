<?php
namespace Admin\Controller;
use Think\Controller;
// 后台公共控制器
class CommonController extends Controller {
  // 在构造函数中执行公共代码
  public function __construct(){
    // 执行ThinkPHP基础控制器类的构造函数
    parent::__construct();

    // 登录防翻墙
    $this->check_login();

    // 权限防翻墙
    $this->check_auth();
  }


  // 权限防翻墙
  public function check_auth(){
    // 设置不需要进行登录防翻墙的页面
    $excep = array(
      'Index-login',  // 登录页面
      'Index-code',   // 验证码页面
      'Index-index',  // 后台首页
      'Index-top',    // 后台首页顶部
      'Index-left',   // 后台首页菜单
      'Index-main' ,  // 后台首页欢迎页面
      'Index-logout', // 退出页面
      'Index-findpwd',// 找回密码页面
      'Index-resetpwd',// 重置密码页面
    );

    // 获取当前页面的控制器名和方法名
    $current = CONTROLLER_NAME . '-' . ACTION_NAME;

    // 判断当前页面是否需要进行权限防翻墙操作
    if( in_array($current, $excep ) ){
      return ;
    }

    // 权限防翻墙
    // 获取当前登录管理员的角色信息
    $where['role_id'] = session('role_id'); // 这个值是在登录时保存在session的
    $roleInfo = D('Role')->where($where)->find();
    $auth = explode(',',$roleInfo['auth_vals']);
    if(  !in_array( $current, $auth ) ){
      // 注意，在开发权限防翻墙功能的时候，先把当前已经做好的功能，设置对应的权限，否则在某些ajax或者删除，编辑操作时，可能因为没有权限而无法获取数据，注意添加完权限以后，还要分配权限
      $this->error('对不起，您不具有访问操作当前页面的权限！');
    }
  }


  // 登录防翻墙
  public function check_login(){
    // 设置不需要进行登录防翻墙的页面
    $excep = array(
      'Index/login', // 登录页面
      'Index/code',  // 验证码页面
      'Index/findpwd', // 找回密码页面
      'Index/resetpwd',// 重置密码页面      
    );

    // 获取当前页面的控制器名和方法名
    $current = CONTROLLER_NAME . '/' . ACTION_NAME;

    // 判断当前页面是否需要进行登录防翻墙操作
    if( in_array($current, $excep ) ){
      return ;
    }

    if( !session('?is_login') ){
      $this->error('对不起！您尚未登录，请登录！', U('Index/login') );
    }
  }
}