<?php
  namespace Admin\Controller;
  use Admin\Controller\CommonController as Controller;
  // 商品属性控制器
  class GoodsAttributeController extends Controller{
    public function _initialize(){
      $this->GoodsAttribute = D('GoodsAttribute');
    }

    // 属性列表页
    public function index(){
      // 总数量
      $this->total = $this->GoodsAttribute->count();
      // 实例化分页类
      $page = new \Think\Page( $this->total, 10 );
      // 分配配置
      $page->rollPage = 3; // 每一页显示的数字页码数量
      $page->lastSuffix = false; // 关闭尾页的数字显示功能
      $page->setConfig('first','首页');
      $page->setConfig('last','尾页');
      $page->setConfig('prev','上页');
      $page->setConfig('next','下页');
      // 生成页码
      $this->pagehtml = $page->show();

      // 根据当前地址栏上id参数显示对应商品类型的属性列表
      $type_id = I('get.id',0,'intval');
      if( $type_id > 0 ){
        $where['ga.type_id'] = $type_id;
      }
      // 查询所有的未删除属性信息
      $this->attributeList = $this->GoodsAttribute->alias('ga')
                                  ->join("__GOODS_TYPE__ as gt ON gt.`type_id`=ga.`type_id`")
                                  ->limit($page->firstRow,$page->listRows)
                                  ->where($where)
                                  ->select();
      // 查询所有的商品类型
      $this->typeList = D('GoodsType')->select();
      // dump($this->attributeList);
      $this->display();
    }

    // 添加
    public function add(){
      // 判断是否有post数据提交
      if( IS_POST ){
        // 使用create接受和校验数据一旦有错误
        // 或者 添加属性信息时有错误
        if( !$this->GoodsAttribute->create() || !$this->GoodsAttribute->add() ){
          $this->error('添加属性失败！' . $this->GoodsAttribute->getError() );
        }
        $this->success('添加属性成功！', U('GoodsAttribute/index') );die;
      }

      // 查询所有的商品类型
      $this->typeList = D('GoodsType')->select();
      $this->display();
    }

    // 编辑
    public function edit(){
      // 判断是否有post数据提交
      if( IS_POST ){
        // 使用create方法接受数据并校验
        // save 保存数据
        if( !$this->GoodsAttribute->create() || !$this->GoodsAttribute->save() ){
          $this->error('编辑属性失败！' . $this->GoodsAttribute->getError() );
        }

        $this->success('编辑属性成功！', U('GoodsAttribute/index') );die;

      }

      // 接受属性ID，并根据ID查询对应的数据
      $attr_id = I('get.id',0,'intval');
      $where['attr_id'] = $attr_id;
      // 属性信息
      $this->GoodsAttribute = $this->GoodsAttribute->find($attr_id);
      if( !$this->GoodsAttribute ){
        $this->error('非法参数，访问失败！');
      }

      $this->display();
    }

    // 删除属性[硬删除]
    public function del(){
      $attr_id = I('get.id',0,'intval');
      $typeInfo = $this->GoodsAttribute->find($attr_id);
      if( !$typeInfo ){
        $this->error('非法参数，访问失败！');
      }

      // 因为上面已经查询了数据啦，所以这里不写编辑条件，模型也知道我们要编辑的是哪一条数据了
      $res = $this->GoodsAttribute->delete(); 
      if( $res ){
        $this->success('删除属性成功！', U('GoodsAttribute/index') );die;
      }
      $this->error('删除属性失败！' . $this->GoodsAttribute->getError() );
    }

    // 批量删除
    public function delall(){
      $goods_list = I('post.id');

      // 因为上面已经查询了数据啦，所以这里不写编辑条件，模型也知道我们要编辑的是哪一条数据了
      $where['attr_id'] = array('IN', $goods_list ); // 等同于 "where attr_id IN ($goods_list)";
      $res = $this->GoodsAttribute->where($where)->delete();
      if( $res ){
        $data = array('status'=>true,'message'=>'删除成功！');
      }else{
        $data = array('status'=>false,'message'=>'删除失败！');
      }
      
      return $this->ajaxReturn($data);
    
    }


    // 获取对应商品类型id的所有属性数据[ajax]
    public function ajax_list(){
      // 如果不是ajax请求，则警告错误！
      if(!IS_AJAX){
        $this->error('非法访问！');
      }

      $type_id = I('post.id',0,'intval');
      $where['type_id'] = $type_id;
      $data = $this->GoodsAttribute->where($where)->select();
      return $this->ajaxReturn( $data );
    }
  }