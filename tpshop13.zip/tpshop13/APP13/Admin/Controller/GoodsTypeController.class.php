<?php
  namespace Admin\Controller;
  use Admin\Controller\CommonController as Controller;
  // 商品类型控制器
  class GoodsTypeController extends Controller{
    public function _initialize(){
      $this->GoodsType = D('GoodsType');
    }

    // 类型列表页
    public function index(){
      // 总数量
      $this->total = $this->GoodsType->count();
      // 实例化分页类
      $page = new \Think\Page( $this->total, 10 );
      // 分配配置
      $page->rollPage = 3; // 每一页显示的数字页码数量
      $page->lastSuffix = false; // 关闭尾页的数字显示功能
      $page->setConfig('first','首页');
      $page->setConfig('last','尾页');
      $page->setConfig('prev','上页');
      $page->setConfig('next','下页');
      // 生成页码
      $this->pagehtml = $page->show();

      // 查询所有的未删除类型信息
      $this->typeList = $this->GoodsType->limit($page->firstRow,$page->listRows)
                                        ->select();
      $this->display();
    }

    // 添加
    public function add(){
      // 判断是否有post数据提交
      if( IS_POST ){
        // 使用create接受和校验数据一旦有错误
        // 或者 添加类型信息时有错误
        if( !$this->GoodsType->create() || !$this->GoodsType->add() ){
          $this->error('添加类型失败！' . $this->GoodsType->getError() );
        }
        $this->success('添加类型成功！', U('GoodsType/index') );die;
      }
      $this->display();
    }

    // 编辑
    public function edit(){
      // 判断是否有post数据提交
      if( IS_POST ){
        // 使用create方法接受数据并校验
        // save 保存数据
        if( !$this->GoodsType->create() || !$this->GoodsType->save() ){
          $this->error('编辑类型失败！' . $this->GoodsType->getError() );
        }

        $this->success('编辑类型成功！', U('GoodsType/index') );die;

      }

      // 接受类型ID，并根据ID查询对应的数据
      $type_id = I('get.id',0,'intval');
      $where['type_id'] = $type_id;
      // 类型信息
      $this->goodsType = $this->GoodsType->find($type_id);
      if( !$this->goodsType ){
        $this->error('非法参数，访问失败！');
      }

      $this->display();
    }

    // 删除类型[硬删除]
    public function del(){
      $type_id = I('get.id',0,'intval');
      $typeInfo = $this->GoodsType->find($type_id);
      if( !$typeInfo ){
        $this->error('非法参数，访问失败！');
      }

      // 因为上面已经查询了数据啦，所以这里不写编辑条件，模型也知道我们要编辑的是哪一条数据了
      $res = $this->GoodsType->delete(); 
      if( $res ){
        $this->success('删除类型成功！', U('GoodsType/index') );die;
      }
      $this->error('删除类型失败！' . $this->GoodsType->getError() );
    }

    // 批量删除
    public function delall(){
      $goods_list = I('post.id');

      // 因为上面已经查询了数据啦，所以这里不写编辑条件，模型也知道我们要编辑的是哪一条数据了
      $where['type_id'] = array('IN', $goods_list ); // 等同于 "where type_id IN ($goods_list)";
      $res = $this->GoodsType->where($where)->delete();
      if( $res ){
        $data = array('status'=>true,'message'=>'删除成功！');
      }else{
        $data = array('status'=>false,'message'=>'删除失败！');
      }
      
      return $this->ajaxReturn($data);
    
    }

  }