<?php
  namespace Admin\Controller;
  use Admin\Controller\CommonController as Controller;
  // 后台首页控制器
  class IndexController extends Controller {
    // 后台主框架页
    public function index(){

      $this->display();
    }

    // 顶部页面
    public function top(){
      // D('goodsInfo')->find(27); // 这里先使用了find以后。
      // D('goodsInfo')->goods_number = 600;
      // // 再次使用save，如果在不给save传参数的情况下，使用AR模式不需要条件
      // // 如果给save传参数，那么就需要加上条件
      // dump( D('goodsInfo')->save() ); 
      $this->display();
    }

    // 左边菜单栏
    public function left(){
      // 获取当前登录管理员的角色信息
      $where['role_id'] = session('role_id'); // 这个值是在登录时保存在session的
      $roleInfo = D('Role')->where($where)->find();

      // 获取当前登录管理员所拥有的权限信息[顶级权限]
      $top_where['auth_id']  = array('IN',$roleInfo['auth_ids'] );
      $top_where['auth_pid'] = 0;
      $top_where['is_menu']  = 1;
      $this->topAuth = D('Auth')->where($top_where)->select();
      
      // 获取当前登录管理员所拥有的权限信息[子权限]
      $son_where['auth_id']  = array('IN',$roleInfo['auth_ids'] );
      $son_where['auth_pid'] = array('NEQ',0); 
      $son_where['is_menu']  = 1;      
      $this->sonAuth = D('Auth')->where($son_where)->select();

      $this->display();
    }

    // 右边主页面
    public function main(){
      $this->display();
    }

    // 管理员登录
    public function login(){
      // 判断是否有post数据提交
      if( IS_POST ){
        // 判断验证码是否正确
        $code = I('post.verify'); // 用户提交的验证码
        $verify = new \Think\Verify();
        if( !$verify->check($code) ){
          $this->error('验证码错误！');
        }

        // 根据用户提交的帐号获取用户信息
        $where['username'] = I('post.username');
        $adminInfo = D('Admin')->where( $where )->find();
        if( !$adminInfo ){
          $this->error('帐号或密码错误！');
        }

        // 判断密码是否正确
        $password = I('post.password'); // 登录页面提交过来的用户密码
        $salt     = $adminInfo['salt'];    // 保存在数据表中的盐值
        $pwd      = $adminInfo['password'];// 保存在数据表中的密码加密串 
        // 使用自定义的辅助函数password把用户密码和盐值进行加密，判断生成的加密串是否和数据表中$pwd一致。
        if( password($password, $salt) == $pwd ){
          // 保存登录状态
          session('is_login',1);
          session('user_name',$adminInfo['username']);
          session('role_id', $adminInfo['role_id']);
          // 更新当前管理员的登录状态
          D('Admin')->login_time = time();
          D('Admin')->login_ip = ip2long( $_SERVER['REMOTE_ADDR'] ); // 客户端的IP地址
          D('Admin')->save();
          $this->success('登录成功！', U('Index/index') );die;
        }else{
          $this->error('帐号或密码错误！');
        }
      }
      $this->display();
    }
    // 管理员退出
    public function logout(){

      session('is_login',null);
      session('user_name',null);
      session('role_id',null);

      $this->error('对不起！您尚未登录，请登录！', U('Index/login') );
    }
    
    // 验证码
    public function code(){
      $config = array(
        'fontSize' => 24,   // 字体大小
        'length'   => 2,    // 验证码个数
        'imageW'   => 220,  // 图片宽度
      );
      $verify = new \Think\Verify($config);
      $verify->entry();
    }

    // 找回密码
    public function findpwd(){
      // 判断是否有post数据提交
      if( IS_POST ){
        // 根据邮箱地址和帐号查询对应的管理员信息
        $where['username'] = I("post.username");
        $where['email']    = I("post.email");
        // 用户信息
        $adminInfo = D('Admin')->where( $where )->find();
        if( !$adminInfo ){
          $this->error('帐号或邮箱地址不正确！请重新确认！');
        }

        // 生成随机串，保存到数据表中，防止恶意发送邮件
        $token = create_string(32);
        D("Admin")->token = $token;
        D("Admin")->save(); // 保存token到数据表中
        // 重置密码的链接地址[注意，U函数默认情况下不生成域名,我们可以通过第四个参数设置生成域名]
        $url = U('Index/resetpwd', array('token'=>$token ),true,true );
        // 邮件正文
        $content = "尊敬的用户：<br>您正在通过邮件找回密码，请尽快点击<a href='$url'>当前链接</a>，进行密码重置";
        // 发送邮件
        $res = sendMail($adminInfo['mail'], $adminInfo['username'],'找回密码',$content );
        if( $res ){
          $this->success('发送邮件成功！请尽快重置密码！', U('Index/login') );die;
        }else{
          $this->error('发送邮件失败！请联系管理员！');die;
        }
      }
      $this->display();
    }

    // 重置密码
    public function resetpwd(){
      $admin = D('Admin');
      // 判断是否有post数据提交
      if( IS_POST ){
        $password  = I('post.password');
        $password2 = I('post.password2');
        if( $password != $password2 ){
          $this->error('重置密码失败！密码和确认密码必须一致！');
        }
        $data['salt'] = create_string(6);
        $data['password'] = password( $password, $data['salt'] );
        $token = I('post.token');
        $w['token'] = $token;
        $res = $admin->where( $w )->save( $data );
        if( $res ){
          // 重置密码成功以后，删除token值
          $msg['token'] = null;
          $admin->where( $w )->save($msg);
          // 跳转到登录页面，让管理员使用新的密码进行登录
          $this->success('重置密码成功！', U('Index/login') );die;
        }else{
          $this->error('重置密码失败！');
        }
      }

      // 接受找回密码的token值
      $token = I('get.token');
      // 通过token到数据表中查询信息
      $where['token'] = $token;
      $this->adminInfo = $admin->where($where)->find();
      if( !$this->adminInfo ){       // 判断是否能查询到对应的用户信息
        $this->error('非法访问！当前页面不存在！', U('Index/login') );die;
      }

      $this->display();

    }
  }