<?php
return array(
	//'配置项'=>'配置值'
  // 模板常量
  'TMPL_PARSE_STRING' => array(
    '__JS__'  => '/Public/Admin/js',
    '__CSS__' => '/Public/Admin/css',
    '__IMG__' => '/Public/Admin/images',
  ),
);