<?php
  namespace Admin\Model;
  use Think\Model;
  // 订单模型
  class OrderModel extends Model{
    // 表名
    protected $tableName = "order_info";
    // 字段定义
    protected $pk = 'order_id';// 主键
    protected $fields = array('order_id', 'user_id', 'order_number', 'order_price', 'order_pay', 'invoice_head', 'invoice_company', 'invoice_content', 'consignee_name', 'consignee_address', 'consignee_mobile', 'order_status', 'shipping_com', 'shipping_number', 'created_at');
    // 我们一般会把订单状态设置为模型的属性或全局常量，或者开发中也会有人把订单状态设置为配置项
    public $status = array(
      0 => '已下单，未付款',
      1 => '已付款，等待确认',
      2 => '已确认，等待发货',
      3 => '已发货，等待收货',
      5 => '已收货，确认完成',
      6 => '已完成',
    );
  }