<?php
  namespace Admin\Model;
  use Think\Model;
  // 商品相册模型
  class GoodsPicsModel extends Model{
    // 表名
    protected $tableName = "goods_pics";
    // 字段定义
    protected $pk = 'pics_id';// 主键
    protected $fields = array('pics_id', 'goods_id', 'pics_bg', 'pics_md', 'pics_sm');

    // 自动验证
    protected $_validate = array(
      array('goods_id', 'require', '商品ID必须填写', 1, '', 3),
    );

    // 处理多个上传图片
    public function mul_pics(){
        $config = array(
          'rootPath' => "./Uploads/",   // 这里的目录需要手动创建
          'savePath' => "Pics/",       // 这里的目录由ThinkPHP自动生成
          'maxSize'  => 8388608,  // 选中要运算的表达式，快捷键 Ctrl + Shift + Y ，进行数学运算
          'exts'     => array('png','jpeg','gif','jpg'),
        );

        $upload = new \Think\Upload($config);  // 实例化上传文件操作类
        $info = $upload->upload(); // 调用多个文件处理的方法
        $image = new \Think\Image();
        $goods_id = I('post.goods_id');
        // 把所有的大图进行循环，在循环中分别生成每一个大图对应的中图和小图
        $data = []; // 声明一个空变量，用来存储图片地址
        foreach( $info as $key => $item ){
          $pics_bg = $item['savepath'] . $item['savename'];
          $data[$key]['pics_bg'] = $pics_bg;
          $image->open( "./Uploads/". $pics_bg ); // 打开大图
          // 生成缩略图[中图 350x350]
          $pics_md = $item['savepath'] . 'md_' . $item['savename'];
          $data[$key]['pics_md'] = $pics_md;
          $image->thumb(350,350,2)->save(  "./Uploads/" . $pics_md );
          // 生成缩略图[小图 50x50]
          $pics_sm = $item['savepath'] . 'sm_' . $item['savename'];
          $data[$key]['pics_sm'] = $pics_sm;
          $image->thumb(50,50,2)->save(  "./Uploads/" . $pics_sm );
          $data[$key]['goods_id'] = $goods_id;
        }
        // 调用当前模型内置的addAll方法，批量添加数据
        $res = $this->addAll( $data );
        return $res;
    }
  }