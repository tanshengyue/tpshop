<?php
  namespace Admin\Model;
  use Think\Model;
  // 角色模型
  class RoleAttributeModel extends Model{
    // 表名
    protected $tableName = "role";
    // 字段定义
    protected $pk = 'role_id';// 主键
    protected $fields = array('role_id', 'role_name', 'auth_ids', 'auth_vals');

    // 自动验证
    protected $_validate = array(
      array('role_name', 'require', '角色名称必须填写', 1, '', 3),
      array('role_name', '', '角色名称已存在！', 1, 'unique', 3),
    );

  }