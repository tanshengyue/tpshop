<?php
  namespace Admin\Model;
  use Think\Model;
  // 商品属性模型
  class GoodsAttributeModel extends Model{
    // 表名
    protected $tableName = "goods_attribute";
    // 字段定义
    protected $pk = 'attr_id';// 主键
    protected $fields = array('attr_id', 'attr_name', 'type_id', 'attr_sel', 'attr_write', 'attr_vals');

    // 自动验证
    protected $_validate = array(
      array('attr_name', 'require', '属性名称必须填写', 1, '', 3),
      array('attr_name', '', '属性名称已存在！', 1, 'unique', 3),
      array('type_id','require','属性类型必须填写',1,'',3),
    );

    // 自动完成
    protected $_auto = array(
      array('attr_vals', 'transform', 3, 'callback'),
    );

    // 把中文逗号转换成英文逗号
    public function transform($data){
      return str_replace('，',',',$data);
    }

  }