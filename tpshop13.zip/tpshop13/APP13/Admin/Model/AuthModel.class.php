<?php
  namespace Admin\Model;
  use Think\Model;
  // 权限模型
  class AuthModel extends Model{
    // 表名
    protected $tableName = "auth";
    // 字段定义
    protected $pk = 'auth_id';// 主键
    protected $fields = array('auth_id', 'auth_name', 'auth_pid', 'auth_controller', 'auth_action', 'is_menu');

    // 自动验证
    protected $_validate = array(
      array('auth_name', 'require', '权限名称必须填写', 1, '', 3),
      // array('auth_pid','require','父级权限必须填写',1,'',3),
    );

  }