<?php
  namespace Admin\Model;
  use Think\Model;
  // 商品类型模型
  class GoodsTypeModel extends Model{
    // 表名
    protected $tableName = "goods_type";
    // 字段定义
    protected $pk = 'type_id';// 主键
    protected $fields = array('type_id', 'type_name');

    // 自动验证
    protected $_validate = array(
      array('type_name', 'require', '类型名称必须填写', 1, '', 3),
      array('type_name', '', '类型名称必须填写', 1, 'unique', 3),
    );
  }