<?php
  namespace Admin\Model;
  use Think\Model;
  // 商品属性值模型
  class GoodsAttributeValueModel extends Model{
    // 表名
    protected $tableName = "goods_attribute_value";
    // 字段定义
    protected $pk = 'value_id';// 主键
    protected $fields = array('value_id', 'goods_id', 'attr_id', 'attr_value', 'attr_price');

    // 自动验证
    protected $_validate = array(
      array('attr_value', 'require', '属性值必须填写', 1, '', 3),
      array('attr_id',    'require', '属性值ID必须填写', 1, '', 3),
      array('goods_id',   'require', '商品ID必须填写', 1, '', 3),
    );
  }