<?php
$val=max('string',array(2,5,7,),42);
echo $val;