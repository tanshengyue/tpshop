<?php
  // 快递接口
  $key = "e46ad5cbf651c868"; // 应用密钥
  $com = "jd"; // 快递公司[可以为空！]
  $nu  = "70929598229"; // 快递单号
  $url = "http://www.kuaidi100.com/applyurl?key=$key&com=$com&nu=$nu";
  $kuaidi = file_get_contents( $url);
  echo <<<DDD
  <iframe src="$kuaidi" style="width: 600px; height: 340px;" frameborder="0"></iframe>
DDD;

